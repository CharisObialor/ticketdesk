// Entry point. On cPanel set this as the "Application startup file" in Setup Node.js App.
const fs = require('fs');
const http = require('http');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const config = require('./src/config');
const db = require('./src/db');
const realtime = require('./src/realtime');
const jobs = require('./src/jobs');
const { errorHandler, now } = require('./src/util');

const publicDir = path.join(__dirname, 'public');

// HTML pages reference assets with ?v=<build> so assets can be cached for a long time.
const build = `${require('./package.json').version}-${Date.now().toString(36)}`;
const pages = {};
function page(name) {
  if (!pages[name] || !config.isProd) {
    pages[name] = fs
      .readFileSync(path.join(publicDir, name), 'utf8')
      .replaceAll('__V__', build)
      .replaceAll('__APP_NAME__', config.appName.replace(/[<>&"]/g, ''));
  }
  return pages[name];
}
const sendPage = (name) => (req, res) => res.set('Cache-Control', 'no-cache').type('html').send(page(name));

async function seedAdmin() {
  const row = await db.one('SELECT COUNT(*) AS n FROM users');
  if (Number(row.n) > 0) return;
  const { name, email, password } = config.admin;
  if (!email || !password) {
    console.warn('[setup] No users yet. Set ADMIN_EMAIL and ADMIN_PASSWORD in .env, or run: npm run create-admin');
    return;
  }
  await db.query(
    "INSERT INTO users (name, email, password_hash, role, is_active, notify_email, created_at) VALUES (?, ?, ?, 'admin', 1, 1, ?)",
    [name, email.toLowerCase(), await bcrypt.hash(password, 11), now()]
  );
  console.log(`[setup] Created admin account ${email}`);
}

async function main() {
  await db.init();
  await seedAdmin();

  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          'img-src': ["'self'", 'data:', 'blob:'],
          'connect-src': ["'self'", config.appUrl.replace(/^http/, 'ws')],
          'upgrade-insecure-requests': config.appUrl.startsWith('https://') ? [] : null,
        },
      },
      strictTransportSecurity: config.appUrl.startsWith('https://'),
    })
  );
  app.use(compression());
  app.use(express.json({ limit: '1mb' }));
  app.use(cookieParser());

  app.use('/api', require('./src/routes'));
  app.get(['/', '/index.html'], sendPage('index.html'));
  app.get(['/login', '/login.html'], sendPage('login.html'));
  app.use(express.static(publicDir, { index: false, maxAge: config.isProd ? '30d' : 0, immutable: config.isProd }));
  app.use((req, res) => res.redirect('/'));
  app.use(errorHandler);

  const server = http.createServer(app);
  realtime.init(server);
  jobs.start();
  server.listen(config.port, () => console.log(`${config.appName} running on port ${config.port} (${config.db.client})`));
}

main().catch((err) => {
  console.error('Failed to start:', err);
  process.exit(1);
});
