const router = require('express').Router();
const config = require('../config');
const db = require('../db');
const realtime = require('../realtime');
const { TICKET_SELECT } = require('../services/tickets');
const { requireStaff } = require('../auth');
const { wrap, now, parseTs, OPEN_STATUSES, PRIORITIES } = require('../util');

const minutesBetween = (a, b) => (parseTs(b) - parseTs(a)) / 60000;
const avg = (xs) => (xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : null);
const median = (xs) => {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};

// Buckets are UTC days, or ISO-ish weeks (starting Monday) for longer ranges.
function buckets(days) {
  const weekly = days > 31;
  const out = [];
  const end = new Date();
  end.setUTCHours(0, 0, 0, 0);
  const start = new Date(end.getTime() - (days - 1) * 864e5);
  if (weekly) start.setUTCDate(start.getUTCDate() - ((start.getUTCDay() + 6) % 7));
  for (let d = new Date(start); d <= end; d = new Date(d.getTime() + (weekly ? 7 : 1) * 864e5)) {
    out.push({ key: d.toISOString().slice(0, 10), created: 0, resolved: 0 });
  }
  const keyOf = (ts) => {
    const d = parseTs(ts);
    d.setUTCHours(0, 0, 0, 0);
    if (weekly) d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
    return d.toISOString().slice(0, 10);
  };
  return { list: out, index: new Map(out.map((b) => [b.key, b])), keyOf, weekly };
}

router.get(
  '/',
  requireStaff,
  wrap(async (req, res) => {
    const days = [7, 30, 90, 365].includes(Number(req.query.days)) ? Number(req.query.days) : 30;
    const since = now(new Date(Date.now() - days * 864e5));
    const openIn = db.inList(OPEN_STATUSES);

    const [statusRows, openAgg, created, resolved, escalations, byCompany, workload, staffRows, messages, recent] = await Promise.all([
      db.query('SELECT status, COUNT(*) AS n FROM tickets GROUP BY status'),
      db.one(
        `SELECT SUM(CASE WHEN escalated = 1 THEN 1 ELSE 0 END) AS escalated,
          SUM(CASE WHEN assigned_to IS NULL THEN 1 ELSE 0 END) AS unassigned,
          SUM(CASE WHEN priority = 'urgent' THEN 1 ELSE 0 END) AS urgent
         FROM tickets WHERE status IN (${openIn})`,
        OPEN_STATUSES
      ),
      db.query('SELECT id, priority, category, created_at, first_response_at FROM tickets WHERE created_at >= ?', [since]),
      db.query('SELECT id, created_at, resolved_at, assigned_to FROM tickets WHERE resolved_at IS NOT NULL AND resolved_at >= ?', [since]),
      db.one('SELECT COUNT(*) AS n FROM tickets WHERE escalated_at IS NOT NULL AND escalated_at >= ?', [since]),
      db.query(
        `SELECT c.name, COUNT(*) AS total FROM tickets t JOIN companies c ON c.id = t.company_id
         WHERE t.created_at >= ? GROUP BY c.id, c.name ORDER BY total DESC LIMIT 8`,
        [since]
      ),
      db.query(
        `SELECT assigned_to, COUNT(*) AS open_count, SUM(CASE WHEN escalated = 1 THEN 1 ELSE 0 END) AS escalated
         FROM tickets WHERE status IN (${openIn}) AND assigned_to IS NOT NULL GROUP BY assigned_to`,
        OPEN_STATUSES
      ),
      db.query("SELECT id, name, role, last_seen_at FROM users WHERE role IN ('admin', 'agent') AND is_active = 1 ORDER BY name"),
      db.one("SELECT COUNT(*) AS n FROM messages WHERE kind = 'message' AND created_at >= ?", [since]),
      db.query(`${TICKET_SELECT} ORDER BY t.last_activity_at DESC LIMIT 8`),
    ]);

    const status = Object.fromEntries(statusRows.map((r) => [r.status, Number(r.n)]));
    const series = buckets(days);
    for (const t of created) {
      const b = series.index.get(series.keyOf(t.created_at));
      if (b) b.created++;
    }
    for (const t of resolved) {
      const b = series.index.get(series.keyOf(t.resolved_at));
      if (b) b.resolved++;
    }

    const firstResponse = created.filter((t) => t.first_response_at).map((t) => minutesBetween(t.created_at, t.first_response_at));
    const resolution = resolved.map((t) => minutesBetween(t.created_at, t.resolved_at));

    // SLA: tickets that got a first response in time vs. those that missed it (answered late or still overdue).
    let slaMet = 0;
    let slaMissed = 0;
    for (const t of created) {
      const limit = config.slaMinutes[t.priority] || config.slaMinutes.normal;
      const waited = t.first_response_at ? minutesBetween(t.created_at, t.first_response_at) : minutesBetween(t.created_at, now());
      if (t.first_response_at && waited <= limit) slaMet++;
      else if (waited > limit) slaMissed++;
    }

    const count = (rows, key) => rows.reduce((m, r) => ((m[r[key]] = (m[r[key]] || 0) + 1), m), {});
    const resolvedBy = count(resolved, 'assigned_to');
    const load = new Map(workload.map((w) => [Number(w.assigned_to), w]));
    const presence = realtime.presence();
    const onlineIds = new Set(presence.users.map((u) => u.id));

    res.json({
      days,
      weekly: series.weekly,
      kpis: {
        raised: created.length,
        resolved: resolved.length,
        open: OPEN_STATUSES.reduce((s, k) => s + (status[k] || 0), 0),
        escalatedOpen: Number(openAgg.escalated) || 0,
        escalationsInPeriod: Number(escalations.n) || 0,
        unassigned: Number(openAgg.unassigned) || 0,
        urgentOpen: Number(openAgg.urgent) || 0,
        avgFirstResponseMin: avg(firstResponse),
        medianFirstResponseMin: median(firstResponse),
        avgResolutionMin: avg(resolution),
        slaMet,
        slaMissed,
        messages: Number(messages.n) || 0,
      },
      status,
      series: series.list,
      byPriority: PRIORITIES.map((p) => ({ name: p, total: created.filter((t) => t.priority === p).length })),
      byCategory: Object.entries(count(created, 'category'))
        .map(([name, total]) => ({ name, total }))
        .sort((a, b) => b.total - a.total),
      byCompany: byCompany.map((r) => ({ name: r.name, total: Number(r.total) })),
      agents: staffRows.map((s) => ({
        id: s.id,
        name: s.name,
        role: s.role,
        online: onlineIds.has(s.id),
        last_seen_at: s.last_seen_at,
        open: Number(load.get(s.id)?.open_count) || 0,
        escalated: Number(load.get(s.id)?.escalated) || 0,
        resolved: resolvedBy[s.id] || 0,
      })),
      online: presence,
      recent,
    });
  })
);

module.exports = router;
