const router = require('express').Router();
const db = require('../db');
const notify = require('../notify');
const realtime = require('../realtime');
const transcript = require('../transcript');
const svc = require('../services/tickets');
const { upload, cleanup } = require('../uploads');
const { requireAuth, requireStaff, isStaff, canAccessTicket } = require('../auth');
const { wrap, now, HttpError, STATUSES, OPEN_STATUSES, PRIORITIES, CATEGORIES, STATUS_LABELS } = require('../util');

router.use(requireAuth);

const PAGE_SIZE = 50;
const clean = (v, max) => String(v ?? '').trim().slice(0, max);
const cap = (s) => s[0].toUpperCase() + s.slice(1);

// Wraps a multer route so uploaded files are removed if the handler fails.
const withFiles = (fn) =>
  wrap(async (req, res) => {
    try {
      await fn(req, res);
    } catch (err) {
      cleanup(req.files);
      throw err;
    }
  });

async function loadTicket(req) {
  const t = await svc.getTicket(Number(req.params.id));
  if (!canAccessTicket(req.user, t)) throw new HttpError(404, 'Ticket not found');
  return t;
}

router.get(
  '/',
  wrap(async (req, res) => {
    const u = req.user;
    const staff = isStaff(u);
    const where = [];
    const params = [];
    const openIn = `t.status IN (${db.inList(OPEN_STATUSES)})`;
    if (!staff) {
      where.push('t.company_id = ?');
      params.push(u.company_id);
    }
    switch (req.query.view || 'open') {
      case 'open':
        where.push(openIn);
        params.push(...OPEN_STATUSES);
        break;
      case 'mine':
        where.push(staff ? 't.assigned_to = ?' : 't.created_by = ?', openIn);
        params.push(u.id, ...OPEN_STATUSES);
        break;
      case 'unassigned':
        where.push('t.assigned_to IS NULL', openIn);
        params.push(...OPEN_STATUSES);
        break;
      case 'escalated':
        where.push('t.escalated = 1', openIn);
        params.push(...OPEN_STATUSES);
        break;
      case 'resolved':
        where.push("t.status IN ('resolved', 'closed')");
        break;
    }
    if (PRIORITIES.includes(req.query.priority)) {
      where.push('t.priority = ?');
      params.push(req.query.priority);
    }
    if (STATUSES.includes(req.query.status)) {
      where.push('t.status = ?');
      params.push(req.query.status);
    }
    if (staff && req.query.company_id) {
      where.push('t.company_id = ?');
      params.push(Number(req.query.company_id));
    }
    const q = clean(req.query.q, 100);
    if (q) {
      if (/^#?\d+$/.test(q)) {
        where.push('t.id = ?');
        params.push(Number(q.replace('#', '')));
      } else {
        where.push('(t.subject LIKE ? OR c.name LIKE ? OR cu.name LIKE ?)');
        params.push(`%${q}%`, `%${q}%`, `%${q}%`);
      }
    }
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const rows = await db.query(
      `${svc.TICKET_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
       ORDER BY t.last_activity_at DESC LIMIT ? OFFSET ?`,
      [...params, PAGE_SIZE + 1, (page - 1) * PAGE_SIZE]
    );
    res.json({ tickets: rows.slice(0, PAGE_SIZE), hasMore: rows.length > PAGE_SIZE, page });
  })
);

// Badge counts for the sidebar.
router.get(
  '/counts',
  wrap(async (req, res) => {
    const u = req.user;
    const staff = isStaff(u);
    const row = await db.one(
      `SELECT COUNT(*) AS open,
        SUM(CASE WHEN ${staff ? 'assigned_to' : 'created_by'} = ? THEN 1 ELSE 0 END) AS mine,
        SUM(CASE WHEN assigned_to IS NULL THEN 1 ELSE 0 END) AS unassigned,
        SUM(CASE WHEN escalated = 1 THEN 1 ELSE 0 END) AS escalated
       FROM tickets WHERE status IN (${db.inList(OPEN_STATUSES)}) ${staff ? '' : 'AND company_id = ?'}`,
      [u.id, ...OPEN_STATUSES, ...(staff ? [] : [u.company_id])]
    );
    res.json(Object.fromEntries(Object.entries(row).map(([k, v]) => [k, Number(v) || 0])));
  })
);

router.post(
  '/',
  upload.array('files'),
  withFiles(async (req, res) => {
    const u = req.user;
    const staff = isStaff(u);
    const subject = clean(req.body.subject, 255);
    const body = clean(req.body.body, 50000);
    if (!subject || !body) throw new HttpError(400, 'Subject and description are required');
    const priority = PRIORITIES.includes(req.body.priority) ? req.body.priority : 'normal';
    const category = CATEGORIES.includes(req.body.category) ? req.body.category : 'General';

    let companyId = u.company_id;
    let createdBy = u.id;
    if (staff) {
      companyId = Number(req.body.company_id);
      if (!(await db.one('SELECT id FROM companies WHERE id = ?', [companyId]))) throw new HttpError(400, 'Choose a company');
      if (req.body.requester_id) {
        const requester = await db.one('SELECT id FROM users WHERE id = ? AND company_id = ?', [Number(req.body.requester_id), companyId]);
        if (!requester) throw new HttpError(400, 'Requester does not belong to that company');
        createdBy = requester.id;
      }
    }
    if (!companyId) throw new HttpError(400, 'Your account is not linked to a company. Please contact support.');

    const ts = now();
    const r = await db.query(
      `INSERT INTO tickets (company_id, created_by, subject, category, priority, status, first_response_at, created_at, updated_at, last_activity_at)
       VALUES (?, ?, ?, ?, ?, 'open', ?, ?, ?, ?)`,
      [companyId, createdBy, subject, category, priority, staff ? ts : null, ts, ts, ts]
    );
    const t = await svc.getTicket(r.insertId);
    await svc.addMessage(t, u, { body, files: req.files });
    realtime.toTicket(t, 'ticket:new', { ticket: t });
    notify.ticketCreated(t, u, body, req.files.length);
    res.status(201).json({ ticket: t });
  })
);

router.get(
  '/:id',
  wrap(async (req, res) => {
    const t = await loadTicket(req);
    const staff = isStaff(req.user);
    const [messages, transcripts] = await Promise.all([
      svc.getMessages(t.id, staff),
      staff
        ? db.query(
            `SELECT tr.id, tr.filename, tr.size, tr.message_count, tr.reason, tr.created_at, u.name AS created_by_name
             FROM transcripts tr LEFT JOIN users u ON u.id = tr.created_by WHERE tr.ticket_id = ? ORDER BY tr.id DESC`,
            [t.id]
          )
        : [],
    ]);
    res.json({ ticket: t, messages, transcripts });
  })
);

router.post(
  '/:id/messages',
  upload.array('files'),
  withFiles(async (req, res) => {
    const u = req.user;
    const staff = isStaff(u);
    const t = await loadTicket(req);
    const body = clean(req.body.body, 50000);
    if (!body && !req.files.length) throw new HttpError(400, 'Write a message or attach a file');
    if (!staff && t.status === 'closed') throw new HttpError(400, 'This ticket is closed. Please open a new ticket.');
    const internal = staff && ['1', 'true'].includes(String(req.body.internal));

    const message = await svc.addMessage(t, u, { body: body || '(attachment)', internal, files: req.files });

    const fields = {};
    let newStatus = null;
    if (!internal) {
      if (staff) {
        if (!t.first_response_at) fields.first_response_at = now();
        if (!t.assigned_to) fields.assigned_to = u.id;
        if (t.status === 'open') newStatus = 'in_progress';
      } else if (['awaiting_client', 'resolved'].includes(t.status)) {
        newStatus = 'open';
      }
    }
    if (newStatus) {
      fields.status = newStatus;
      fields.resolved_at = null;
    }
    const updated = await svc.touch(t.id, fields);
    if (fields.assigned_to) await svc.systemMessage(updated, u, `Picked up by ${u.name}.`);
    if (newStatus) await svc.systemMessage(updated, u, `Status changed from ${STATUS_LABELS[t.status]} to ${STATUS_LABELS[newStatus]}.`);
    notify.messagePosted(updated, u, message, req.files.length, staff);
    res.status(201).json({ message, ticket: updated });
  })
);

router.patch(
  '/:id',
  wrap(async (req, res) => {
    const u = req.user;
    const staff = isStaff(u);
    const t = await loadTicket(req);
    const b = req.body || {};
    const fields = {};
    const notes = [];
    let statusTo = null;
    let assignee = null;

    if (b.status !== undefined && b.status !== t.status) {
      if (!STATUSES.includes(b.status)) throw new HttpError(400, 'Invalid status');
      const clientAllowed =
        (b.status === 'resolved' && OPEN_STATUSES.includes(t.status)) || (b.status === 'open' && t.status === 'resolved');
      if (!staff && !clientAllowed) throw new HttpError(403, 'You cannot make that change');
      fields.status = b.status;
      fields.resolved_at = ['resolved', 'closed'].includes(b.status) ? t.resolved_at || now() : null;
      statusTo = b.status;
      notes.push(`Status changed from ${STATUS_LABELS[t.status]} to ${STATUS_LABELS[b.status]}.`);
    }
    if (staff && b.priority !== undefined && b.priority !== t.priority) {
      if (!PRIORITIES.includes(b.priority)) throw new HttpError(400, 'Invalid priority');
      fields.priority = b.priority;
      notes.push(`Priority changed from ${cap(t.priority)} to ${cap(b.priority)}.`);
    }
    if (staff && b.category !== undefined && b.category !== t.category) {
      if (!CATEGORIES.includes(b.category)) throw new HttpError(400, 'Invalid category');
      fields.category = b.category;
      notes.push(`Category changed to ${b.category}.`);
    }
    if (staff && b.assigned_to !== undefined) {
      const id = b.assigned_to ? Number(b.assigned_to) : null;
      if (id !== (t.assigned_to ? Number(t.assigned_to) : null)) {
        if (id) {
          assignee = await db.one("SELECT id, name FROM users WHERE id = ? AND role IN ('admin', 'agent') AND is_active = 1", [id]);
          if (!assignee) throw new HttpError(400, 'Invalid assignee');
        }
        fields.assigned_to = id;
        notes.push(assignee ? `Assigned to ${assignee.name}.` : 'Ticket unassigned.');
      }
    }

    let updated = Object.keys(fields).length ? await svc.touch(t.id, fields) : t;
    for (const n of notes) await svc.systemMessage(updated, u, n);

    if (b.escalate === true) {
      if (!staff && t.escalated) throw new HttpError(400, 'This ticket is already escalated');
      const reason = clean(b.reason, 500) || (staff ? `Escalated by ${u.name}.` : `Escalation requested by ${u.name} (${t.company_name}).`);
      updated = await svc.escalate(updated, u, reason);
    } else if (b.escalate === false && staff && t.escalated) {
      updated = await svc.touch(t.id, { escalated: 0 });
      await svc.systemMessage(updated, u, 'Escalation cleared.');
    }

    if (statusTo) {
      notify.statusChanged(updated, u, t.status, statusTo, staff);
      if (['resolved', 'closed'].includes(statusTo)) {
        svc.archiveTranscript(updated, u, statusTo).catch((err) => console.error('[transcript] archive failed', err));
      }
    }
    if (assignee) notify.assigned(updated, u);
    res.json({ ticket: updated });
  })
);

const EXPORTS = {
  html: ['text/html', transcript.toHtml],
  txt: ['text/plain', transcript.toText],
  json: ['application/json', transcript.toJson],
};

router.get(
  '/:id/export',
  wrap(async (req, res) => {
    const t = await loadTicket(req);
    const [type, build] = EXPORTS[req.query.format] || EXPORTS.html;
    const ext = EXPORTS[req.query.format] ? req.query.format : 'html';
    const includeInternal = isStaff(req.user) && req.query.internal !== '0';
    const messages = await svc.getMessages(t.id, includeInternal);
    res.attachment(`ticket-${t.id}-transcript.${ext}`);
    res.type(type).send(build(t, messages, { includeInternal }));
  })
);

router.post(
  '/:id/archive',
  requireStaff,
  wrap(async (req, res) => {
    const t = await loadTicket(req);
    const saved = await svc.archiveTranscript(t, req.user, 'manual');
    res.status(201).json(saved);
  })
);

module.exports = router;
