const nodemailer = require('nodemailer');
const config = require('./config');
const { escapeHtml } = require('./util');

let transport;
function getTransport() {
  if (!transport) {
    transport = config.smtp.host
      ? nodemailer.createTransport({
          host: config.smtp.host,
          port: config.smtp.port,
          secure: config.smtp.secure,
          auth: config.smtp.user ? { user: config.smtp.user, pass: config.smtp.pass } : undefined,
        })
      : nodemailer.createTransport({ jsonTransport: true });
  }
  return transport;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Fire-and-forget with retries so a slow SMTP server never delays an API response.
function send({ to, subject, html, text, replyTo }) {
  if (!to) return;
  setImmediate(async () => {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        await getTransport().sendMail({ from: config.smtp.from, to, subject, html, text, replyTo });
        if (!config.smtp.host) console.log(`[mail:dev] to=${to} subject="${subject}"`);
        return;
      } catch (err) {
        console.error(`[mail] attempt ${attempt} to ${to} failed: ${err.message}`);
        if (attempt < 3) await sleep(attempt * 5000);
      }
    }
  });
}

// Simple branded email layout. `quote` is shown as a message excerpt.
function render({ heading, intro, quote, details = [], ctaUrl, ctaLabel }) {
  const rows = details
    .map(
      ([k, v]) =>
        `<tr><td style="padding:4px 12px 4px 0;color:#6b7280;font-size:13px">${escapeHtml(k)}</td><td style="padding:4px 0;font-size:13px;color:#111827">${escapeHtml(v)}</td></tr>`
    )
    .join('');
  const html = `<!doctype html><html><body style="margin:0;background:#f3f4f6;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="padding:24px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#fff;border-radius:10px;overflow:hidden;border:1px solid #e5e7eb">
<tr><td style="background:#1e3a8a;color:#fff;padding:16px 24px;font-weight:600;font-size:15px">${escapeHtml(config.appName)}</td></tr>
<tr><td style="padding:24px">
<h1 style="margin:0 0 12px;font-size:18px;color:#111827">${escapeHtml(heading)}</h1>
${intro ? `<p style="margin:0 0 16px;font-size:14px;line-height:1.5;color:#374151">${escapeHtml(intro)}</p>` : ''}
${rows ? `<table cellpadding="0" cellspacing="0" style="margin:0 0 16px">${rows}</table>` : ''}
${quote ? `<div style="border-left:3px solid #2563eb;background:#f9fafb;padding:12px 14px;margin:0 0 20px;font-size:14px;line-height:1.5;color:#374151;white-space:pre-wrap">${escapeHtml(quote)}</div>` : ''}
${ctaUrl ? `<a href="${escapeHtml(ctaUrl)}" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:10px 18px;border-radius:6px;font-size:14px;font-weight:600">${escapeHtml(ctaLabel || 'Open portal')}</a>` : ''}
</td></tr>
<tr><td style="padding:14px 24px;border-top:1px solid #e5e7eb;font-size:12px;color:#9ca3af">You received this because you have an account on ${escapeHtml(config.appName)}. Notification emails can be turned off on your profile page.</td></tr>
</table></td></tr></table></body></html>`;
  const text = [
    heading,
    '',
    intro,
    ...details.map(([k, v]) => `${k}: ${v}`),
    quote ? `\n> ${String(quote).split('\n').join('\n> ')}\n` : '',
    ctaUrl ? `${ctaLabel || 'Open'}: ${ctaUrl}` : '',
  ]
    .filter((x) => x !== undefined && x !== null)
    .join('\n');
  return { html, text };
}

module.exports = { send, render };
