const { Server } = require('socket.io');
const db = require('./db');
const auth = require('./auth');
const { now } = require('./util');

let io;
const online = new Map(); // userId -> { user, sockets }
let presenceTimer;

function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function init(server) {
  io = new Server(server, {
    serveClient: true,
    // Reject cross-site connections; same-origin browsers always send a matching Origin.
    allowRequest: (req, cb) => {
      const origin = req.headers.origin;
      cb(null, !origin || new URL(origin).host === req.headers.host);
    },
  });

  io.use(async (socket, next) => {
    try {
      const user = await auth.userFromToken(parseCookies(socket.request.headers.cookie)[auth.COOKIE]);
      if (!user) return next(new Error('unauthorized'));
      socket.user = user;
      next();
    } catch (err) {
      next(err);
    }
  });

  io.on('connection', (socket) => {
    const u = socket.user;
    socket.join(`user:${u.id}`);
    if (auth.isStaff(u)) socket.join('staff');
    else if (u.company_id) socket.join(`company:${u.company_id}`);
    track(u, 1);

    socket.on('typing', async ({ ticketId, typing } = {}) => {
      const t = await db.one('SELECT id, company_id FROM tickets WHERE id = ?', [Number(ticketId)]).catch(() => null);
      if (!auth.canAccessTicket(u, t)) return;
      socket
        .to(['staff', `company:${t.company_id}`])
        .emit('typing', { ticketId: t.id, userId: u.id, name: u.name, typing: !!typing });
    });

    socket.on('disconnect', () => track(u, -1));
  });

  return io;
}

function track(user, delta) {
  const entry = online.get(user.id) || { user, sockets: 0 };
  entry.sockets += delta;
  if (entry.sockets > 0) online.set(user.id, entry);
  else {
    online.delete(user.id);
    db.query('UPDATE users SET last_seen_at = ? WHERE id = ?', [now(), user.id]).catch(() => {});
  }
  // Batch presence broadcasts so a burst of reconnects sends a single update.
  clearTimeout(presenceTimer);
  presenceTimer = setTimeout(() => io && io.to('staff').emit('presence', presence()), 500);
}

function presence() {
  const users = [...online.values()].map(({ user: u }) => ({
    id: u.id,
    name: u.name,
    role: u.role,
    company_name: u.company_name || null,
  }));
  const staff = users.filter((u) => auth.isStaff(u)).length;
  return { total: users.length, staff, clients: users.length - staff, users };
}

// Public events go to staff and the ticket's company; internal ones to staff only.
function toTicket(ticket, event, payload, { internal = false } = {}) {
  if (!io || !ticket) return;
  io.to(internal ? ['staff'] : ['staff', `company:${ticket.company_id}`]).emit(event, payload);
}

module.exports = { init, presence, toTicket };
