const config = require('./config');
const db = require('./db');
const mailer = require('./mailer');
const { STATUS_LABELS } = require('./util');

const ticketUrl = (id) => `${config.appUrl}/#/tickets/${id}`;
const excerpt = (s, n = 1200) => (s && s.length > n ? s.slice(0, n) + '…' : s || '');
const tag = (t) => `[#${t.id}]`;

function details(t) {
  return [
    ['Company', t.company_name || '-'],
    ['Priority', cap(t.priority)],
    ['Status', STATUS_LABELS[t.status] || t.status],
    ['Assigned to', t.assignee_name || 'Unassigned'],
  ];
}
const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);

async function staff({ adminsOnly = false } = {}) {
  const roles = adminsOnly ? ['admin'] : ['admin', 'agent'];
  return db.query(
    `SELECT id, name, email FROM users WHERE role IN (${db.inList(roles)}) AND is_active = 1 AND notify_email = 1`,
    roles
  );
}

async function userIfNotifiable(id) {
  if (!id) return null;
  return db.one('SELECT id, name, email FROM users WHERE id = ? AND is_active = 1 AND notify_email = 1', [id]);
}

function sendEach(recipients, actor, build) {
  const seen = new Set();
  for (const r of recipients) {
    if (!r || seen.has(r.id) || (actor && r.id === actor.id)) continue;
    seen.add(r.id);
    const { subject, ...content } = build(r);
    mailer.send({ to: r.email, subject, ...mailer.render(content) });
  }
}

// Staff who should hear about client activity: the assignee if any, otherwise every staff member.
async function ticketWatchers(t) {
  const assignee = await userIfNotifiable(t.assigned_to);
  if (assignee) return [assignee];
  return staff();
}

module.exports = {
  async ticketCreated(t, actor, body, fileCount) {
    const recipients = await staff();
    sendEach(recipients, actor, () => ({
      subject: `${tag(t)} New ticket: ${t.subject}`,
      heading: `New ticket from ${t.company_name}`,
      intro: `${actor.name} opened "${t.subject}"${fileCount ? ` with ${fileCount} attachment(s)` : ''}.`,
      details: [['Category', t.category], ...details(t)],
      quote: excerpt(body),
      ctaUrl: ticketUrl(t.id),
      ctaLabel: 'View ticket',
    }));
  },

  async messagePosted(t, actor, message, fileCount, actorIsStaff) {
    if (message.is_internal) return; // internal notes never trigger email
    const recipients = actorIsStaff ? [await userIfNotifiable(t.created_by)] : await ticketWatchers(t);
    sendEach(recipients, actor, () => ({
      subject: `${tag(t)} New reply: ${t.subject}`,
      heading: `${actor.name} replied`,
      intro: `New update on "${t.subject}"${fileCount ? ` (${fileCount} attachment(s))` : ''}.`,
      details: details(t),
      quote: excerpt(message.body),
      ctaUrl: ticketUrl(t.id),
      ctaLabel: 'Reply in portal',
    }));
  },

  async statusChanged(t, actor, from, to, actorIsStaff) {
    const recipients = actorIsStaff ? [await userIfNotifiable(t.created_by)] : await ticketWatchers(t);
    sendEach(recipients, actor, () => ({
      subject: `${tag(t)} ${STATUS_LABELS[to]}: ${t.subject}`,
      heading: `Ticket marked ${STATUS_LABELS[to]}`,
      intro: `${actor ? actor.name : 'The system'} changed the status from ${STATUS_LABELS[from]} to ${STATUS_LABELS[to]}.`,
      details: details(t),
      ctaUrl: ticketUrl(t.id),
      ctaLabel: 'View ticket',
    }));
  },

  async escalated(t, actor, reason) {
    const recipients = [...(await staff({ adminsOnly: true })), await userIfNotifiable(t.assigned_to)];
    sendEach(recipients, actor, () => ({
      subject: `${tag(t)} ESCALATED (level ${t.escalation_level}): ${t.subject}`,
      heading: 'Ticket escalated',
      intro: reason,
      details: details(t),
      ctaUrl: ticketUrl(t.id),
      ctaLabel: 'Review ticket',
    }));
  },

  async assigned(t, actor) {
    const assignee = await userIfNotifiable(t.assigned_to);
    sendEach([assignee], actor, () => ({
      subject: `${tag(t)} Assigned to you: ${t.subject}`,
      heading: 'A ticket was assigned to you',
      intro: `${actor.name} assigned "${t.subject}" to you.`,
      details: details(t),
      ctaUrl: ticketUrl(t.id),
      ctaLabel: 'Open ticket',
    }));
  },

  invite(user, token) {
    const { html, text } = mailer.render({
      heading: `You're invited to ${config.appName}`,
      intro: `Hi ${user.name}, an account has been created for you. Use the button below to set your password and sign in. The link expires in 72 hours.`,
      ctaUrl: `${config.appUrl}/login?token=${token}`,
      ctaLabel: 'Set your password',
    });
    mailer.send({ to: user.email, subject: `Your ${config.appName} account`, html, text });
  },

  passwordReset(user, token) {
    const { html, text } = mailer.render({
      heading: 'Reset your password',
      intro: `Hi ${user.name}, use the button below to choose a new password. The link expires in 1 hour. If you didn't ask for this, you can ignore this email.`,
      ctaUrl: `${config.appUrl}/login?token=${token}`,
      ctaLabel: 'Reset password',
    });
    mailer.send({ to: user.email, subject: `${config.appName} password reset`, html, text });
  },
};
