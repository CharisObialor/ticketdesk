const mysql = `
CREATE TABLE IF NOT EXISTS companies (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(190) NOT NULL,
  email_domain VARCHAR(190) NULL,
  notes TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NULL,
  name VARCHAR(190) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(100) NULL,
  role VARCHAR(16) NOT NULL DEFAULT 'client',
  phone VARCHAR(40) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  notify_email TINYINT(1) NOT NULL DEFAULT 1,
  token_hash CHAR(64) NULL,
  token_expires DATETIME NULL,
  last_login_at DATETIME NULL,
  last_seen_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_company (company_id),
  CONSTRAINT fk_users_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tickets (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  created_by INT UNSIGNED NULL,
  assigned_to INT UNSIGNED NULL,
  subject VARCHAR(255) NOT NULL,
  category VARCHAR(60) NOT NULL DEFAULT 'General',
  priority VARCHAR(16) NOT NULL DEFAULT 'normal',
  status VARCHAR(20) NOT NULL DEFAULT 'open',
  escalated TINYINT(1) NOT NULL DEFAULT 0,
  escalation_level INT NOT NULL DEFAULT 0,
  escalated_at DATETIME NULL,
  first_response_at DATETIME NULL,
  resolved_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  last_activity_at DATETIME NOT NULL,
  KEY idx_t_company (company_id),
  KEY idx_t_status (status),
  KEY idx_t_assigned (assigned_to),
  KEY idx_t_created (created_at),
  KEY idx_t_resolved (resolved_at),
  KEY idx_t_activity (last_activity_at),
  CONSTRAINT fk_t_company FOREIGN KEY (company_id) REFERENCES companies(id),
  CONSTRAINT fk_t_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_t_assignee FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL,
  body MEDIUMTEXT NOT NULL,
  is_internal TINYINT(1) NOT NULL DEFAULT 0,
  kind VARCHAR(16) NOT NULL DEFAULT 'message',
  created_at DATETIME NOT NULL,
  KEY idx_m_ticket (ticket_id),
  KEY idx_m_created (created_at),
  CONSTRAINT fk_m_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  CONSTRAINT fk_m_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS attachments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT UNSIGNED NOT NULL,
  message_id INT UNSIGNED NULL,
  user_id INT UNSIGNED NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(100) NOT NULL,
  mime VARCHAR(150) NOT NULL,
  size INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  KEY idx_a_ticket (ticket_id),
  KEY idx_a_message (message_id),
  CONSTRAINT fk_a_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
  CONSTRAINT fk_a_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS transcripts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT UNSIGNED NOT NULL,
  filename VARCHAR(150) NOT NULL,
  size INT UNSIGNED NOT NULL,
  message_count INT NOT NULL,
  reason VARCHAR(40) NOT NULL,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  KEY idx_tr_ticket (ticket_id),
  CONSTRAINT fk_tr_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
`;

const sqlite = `
CREATE TABLE IF NOT EXISTS companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email_domain TEXT, notes TEXT,
  is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL,
  name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT, role TEXT NOT NULL DEFAULT 'client',
  phone TEXT, is_active INTEGER NOT NULL DEFAULT 1, notify_email INTEGER NOT NULL DEFAULT 1,
  token_hash TEXT, token_expires TEXT, last_login_at TEXT, last_seen_at TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT, company_id INTEGER NOT NULL REFERENCES companies(id),
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL, assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL,
  subject TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'General', priority TEXT NOT NULL DEFAULT 'normal',
  status TEXT NOT NULL DEFAULT 'open', escalated INTEGER NOT NULL DEFAULT 0, escalation_level INTEGER NOT NULL DEFAULT 0,
  escalated_at TEXT, first_response_at TEXT, resolved_at TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_activity_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_t_company ON tickets(company_id);
CREATE INDEX IF NOT EXISTS idx_t_status ON tickets(status);
CREATE INDEX IF NOT EXISTS idx_t_assigned ON tickets(assigned_to);
CREATE INDEX IF NOT EXISTS idx_t_created ON tickets(created_at);
CREATE INDEX IF NOT EXISTS idx_t_resolved ON tickets(resolved_at);
CREATE INDEX IF NOT EXISTS idx_t_activity ON tickets(last_activity_at);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, body TEXT NOT NULL,
  is_internal INTEGER NOT NULL DEFAULT 0, kind TEXT NOT NULL DEFAULT 'message', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_m_ticket ON messages(ticket_id);
CREATE INDEX IF NOT EXISTS idx_m_created ON messages(created_at);
CREATE TABLE IF NOT EXISTS attachments (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  message_id INTEGER REFERENCES messages(id) ON DELETE CASCADE, user_id INTEGER,
  original_name TEXT NOT NULL, stored_name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_a_ticket ON attachments(ticket_id);
CREATE TABLE IF NOT EXISTS transcripts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  filename TEXT NOT NULL, size INTEGER NOT NULL, message_count INTEGER NOT NULL, reason TEXT NOT NULL,
  created_by INTEGER, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tr_ticket ON transcripts(ticket_id);
`;

module.exports = { mysql, sqlite };
