const config = require('./config');
const db = require('./db');
const tickets = require('./services/tickets');
const { parseTs } = require('./util');

const human = (min) => (min % 1440 === 0 ? `${min / 1440}d` : min % 60 === 0 ? `${min / 60}h` : `${min}m`);

// Auto-escalate tickets that have waited longer than their priority's SLA for a first staff response.
// Only tickets never escalated before are considered, so a manual de-escalation sticks.
async function checkSla() {
  const rows = await db.query(
    `SELECT id, priority, created_at FROM tickets
     WHERE escalation_level = 0 AND first_response_at IS NULL AND status IN ('open', 'in_progress')`
  );
  for (const r of rows) {
    const limit = config.slaMinutes[r.priority] || config.slaMinutes.normal;
    if (Date.now() - parseTs(r.created_at).getTime() < limit * 60000) continue;
    const t = await tickets.getTicket(r.id);
    await tickets.escalate(t, null, `Auto-escalated: no staff response within the ${human(limit)} SLA for ${r.priority} priority.`);
  }
}

function start() {
  const run = () => checkSla().catch((err) => console.error('[jobs] SLA check failed', err));
  setTimeout(run, 15000).unref();
  setInterval(run, 5 * 60 * 1000).unref();
}

module.exports = { start, checkSla };
