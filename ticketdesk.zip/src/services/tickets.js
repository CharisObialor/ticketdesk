const fs = require('fs');
const path = require('path');
const db = require('../db');
const realtime = require('../realtime');
const notify = require('../notify');
const transcript = require('../transcript');
const { transcriptsDir } = require('../uploads');
const { now } = require('../util');

const TICKET_SELECT = `SELECT t.*, c.name AS company_name, cu.name AS creator_name, cu.email AS creator_email,
  au.name AS assignee_name
  FROM tickets t
  JOIN companies c ON c.id = t.company_id
  LEFT JOIN users cu ON cu.id = t.created_by
  LEFT JOIN users au ON au.id = t.assigned_to`;

const getTicket = (id) => db.one(`${TICKET_SELECT} WHERE t.id = ?`, [id]);

async function getMessages(ticketId, includeInternal) {
  const messages = await db.query(
    `SELECT m.*, u.name AS user_name, u.role AS user_role FROM messages m LEFT JOIN users u ON u.id = m.user_id
     WHERE m.ticket_id = ? ${includeInternal ? '' : 'AND m.is_internal = 0'} ORDER BY m.id`,
    [ticketId]
  );
  const atts = await db.query(
    'SELECT id, message_id, original_name, mime, size, created_at FROM attachments WHERE ticket_id = ? ORDER BY id',
    [ticketId]
  );
  const byMessage = new Map();
  for (const a of atts) {
    if (!byMessage.has(a.message_id)) byMessage.set(a.message_id, []);
    byMessage.get(a.message_id).push(a);
  }
  for (const m of messages) m.attachments = byMessage.get(m.id) || [];
  return messages;
}

async function addMessage(ticket, user, { body, internal = false, kind = 'message', files = [] }) {
  const ts = now();
  const r = await db.query(
    'INSERT INTO messages (ticket_id, user_id, body, is_internal, kind, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    [ticket.id, user ? user.id : null, body, internal, kind, ts]
  );
  const attachments = [];
  for (const f of files) {
    const a = await db.query(
      `INSERT INTO attachments (ticket_id, message_id, user_id, original_name, stored_name, mime, size, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [ticket.id, r.insertId, user ? user.id : null, f.originalname, f.filename, f.mimetype, f.size, ts]
    );
    attachments.push({ id: a.insertId, message_id: r.insertId, original_name: f.originalname, mime: f.mimetype, size: f.size, created_at: ts });
  }
  const message = {
    id: r.insertId,
    ticket_id: ticket.id,
    user_id: user ? user.id : null,
    user_name: user ? user.name : null,
    user_role: user ? user.role : null,
    body,
    is_internal: internal ? 1 : 0,
    kind,
    created_at: ts,
    attachments,
  };
  realtime.toTicket(ticket, 'message:new', { ticketId: ticket.id, message }, { internal });
  return message;
}

const systemMessage = (ticket, actor, text) => addMessage(ticket, actor, { body: text, kind: 'system' });

// Updates ticket columns (names come from code, never from input), bumps activity and broadcasts.
async function touch(id, fields = {}) {
  const ts = now();
  const sets = { ...fields, updated_at: ts, last_activity_at: ts };
  const keys = Object.keys(sets);
  await db.query(`UPDATE tickets SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`, [...keys.map((k) => sets[k]), id]);
  const t = await getTicket(id);
  realtime.toTicket(t, 'ticket:update', { ticket: t });
  return t;
}

async function escalate(ticket, actor, reason) {
  const t = await touch(ticket.id, {
    escalated: 1,
    escalation_level: Number(ticket.escalation_level) + 1,
    escalated_at: now(),
  });
  await systemMessage(t, actor, `Escalated to level ${t.escalation_level}. ${reason}`);
  realtime.toTicket(t, 'ticket:escalated', { ticket: t }, { internal: true });
  notify.escalated(t, actor, reason);
  return t;
}

// Saves a full transcript (including internal notes) to storage for reference.
async function archiveTranscript(ticket, actor, reason) {
  const messages = await getMessages(ticket.id, true);
  const html = transcript.toHtml(ticket, messages, { includeInternal: true });
  const filename = `ticket-${ticket.id}-${now().replace(/[-: ]/g, '')}-${Date.now() % 100000}.html`;
  await fs.promises.writeFile(path.join(transcriptsDir, filename), html, 'utf8');
  const r = await db.query(
    'INSERT INTO transcripts (ticket_id, filename, size, message_count, reason, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [ticket.id, filename, Buffer.byteLength(html), messages.length, reason, actor ? actor.id : null, now()]
  );
  return { id: r.insertId, filename };
}

module.exports = { TICKET_SELECT, getTicket, getMessages, addMessage, systemMessage, touch, escalate, archiveTranscript };
