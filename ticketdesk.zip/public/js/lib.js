// Small helpers shared by the app: safe HTML templating, API calls, formatting, toasts and modals.
(function () {
  class Raw {
    constructor(s) {
      this.s = s;
    }
  }
  const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ESC[c]);
  const val = (v) =>
    v == null || v === false ? '' : v instanceof Raw ? v.s : Array.isArray(v) ? v.map(val).join('') : esc(v);

  // Tagged template: every interpolation is escaped unless it is itself an html`` result.
  function html(strings, ...vals) {
    let out = strings[0];
    for (let i = 0; i < vals.length; i++) out += val(vals[i]) + strings[i + 1];
    return new Raw(out);
  }
  const render = (el, tpl) => {
    el.innerHTML = val(tpl);
  };
  const append = (el, tpl) => el.insertAdjacentHTML('beforeend', val(tpl));

  function onUnauthorized() {
    location.href = '/login?next=' + encodeURIComponent(location.pathname + location.hash);
  }

  async function api(method, url, body) {
    const opts = { method, headers: {}, credentials: 'same-origin' };
    if (body instanceof FormData) opts.body = body;
    else if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const res = await fetch('/api' + url, opts);
    if (res.status === 401) {
      onUnauthorized();
      throw new Error('Signed out');
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  }

  // XHR upload so we can show progress for large attachments.
  function upload(url, formData, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api' + url);
      xhr.upload.onprogress = (e) => e.lengthComputable && onProgress && onProgress(e.loaded / e.total);
      xhr.onload = () => {
        if (xhr.status === 401) return onUnauthorized();
        let data = {};
        try {
          data = JSON.parse(xhr.responseText);
        } catch {}
        if (xhr.status >= 200 && xhr.status < 300) resolve(data);
        else reject(new Error(data.error || `Upload failed (${xhr.status})`));
      };
      xhr.onerror = () => reject(new Error('Network error - check your connection'));
      xhr.send(formData);
    });
  }

  const parseTs = (s) => (s ? new Date(String(s).replace(' ', 'T') + 'Z') : null);

  function timeAgo(s) {
    const d = parseTs(s);
    if (!d) return '-';
    const sec = Math.round((Date.now() - d) / 1000);
    if (sec < 45) return 'just now';
    const min = Math.round(sec / 60);
    if (min < 60) return `${min}m ago`;
    const hr = Math.round(min / 60);
    if (hr < 24) return `${hr}h ago`;
    const day = Math.round(hr / 24);
    if (day < 7) return `${day}d ago`;
    return fmtDate(s, false);
  }

  function fmtDate(s, withTime = true) {
    const d = parseTs(s);
    if (!d) return '-';
    return d.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      ...(withTime ? { hour: '2-digit', minute: '2-digit' } : {}),
    });
  }

  function fmtDuration(min) {
    if (min == null) return '-';
    if (min < 1) return '<1m';
    if (min < 60) return `${Math.round(min)}m`;
    if (min < 1440) return `${(min / 60).toFixed(min < 600 ? 1 : 0)}h`;
    return `${(min / 1440).toFixed(1)}d`;
  }

  function fileSize(n) {
    if (n < 1024) return `${n} B`;
    if (n < 1048576) return `${Math.round(n / 1024)} KB`;
    return `${(n / 1048576).toFixed(1)} MB`;
  }

  const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : '');
  const STATUS = { open: 'Open', in_progress: 'In progress', awaiting_client: 'Awaiting client', resolved: 'Resolved', closed: 'Closed' };
  const statusBadge = (s) => html`<span class="badge s-${s}">${STATUS[s] || s}</span>`;
  const priorityBadge = (p) => html`<span class="badge p-${p}">${cap(p)}</span>`;

  function toast(title, body, { type, onClick, ms = 6000 } = {}) {
    const el = document.createElement('div');
    el.className = 'toast' + (type ? ' ' + type : '');
    render(el, html`<b>${title}</b>${body || ''}`);
    el.addEventListener('click', () => {
      el.remove();
      onClick && onClick();
    });
    document.getElementById('toasts').appendChild(el);
    setTimeout(() => el.remove(), ms);
  }

  // Opens a modal; returns { el, close }. Clicking the backdrop or pressing Esc closes it.
  function modal(tpl) {
    const root = document.getElementById('modal-root');
    const back = document.createElement('div');
    back.className = 'modal-back';
    render(back, html`<div class="card modal card-pad">${tpl}</div>`);
    const close = () => {
      back.remove();
      document.removeEventListener('keydown', onKey);
    };
    const onKey = (e) => e.key === 'Escape' && close();
    back.addEventListener('mousedown', (e) => e.target === back && close());
    back.addEventListener('click', (e) => e.target.closest('[data-close]') && close());
    document.addEventListener('keydown', onKey);
    root.appendChild(back);
    const first = back.querySelector('input, select, textarea');
    if (first) first.focus();
    return { el: back, close };
  }

  function debounce(fn, ms) {
    let t;
    return (...a) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...a), ms);
    };
  }

  window.L = {
    html,
    raw: (s) => new Raw(s),
    render,
    append,
    esc,
    api,
    upload,
    parseTs,
    timeAgo,
    fmtDate,
    fmtDuration,
    fileSize,
    cap,
    STATUS,
    statusBadge,
    priorityBadge,
    toast,
    modal,
    debounce,
  };
})();
