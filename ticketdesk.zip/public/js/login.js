(function () {
  const $ = (id) => document.getElementById(id);
  const forms = ['login-form', 'forgot-form', 'reset-form'];
  const show = (id) => forms.forEach((f) => $(f).classList.toggle('hidden', f !== id));
  const params = new URLSearchParams(location.search);
  const token = params.get('token');
  const next = params.get('next') || '/';

  async function post(url, body) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  function setError(id, msg) {
    $(id).textContent = msg || '';
    $(id).classList.toggle('hidden', !msg);
  }

  function busy(form, on) {
    form.querySelector('button[type=submit]').disabled = on;
  }

  document.addEventListener('click', (e) => {
    const link = e.target.closest('[data-show]');
    if (!link) return;
    e.preventDefault();
    show(link.dataset.show);
  });

  $('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    setError('login-error');
    busy(f, true);
    try {
      await post('/api/auth/login', { email: f.email.value, password: f.password.value });
      // Only follow same-site relative paths after login.
      location.href = next.startsWith('/') && !next.startsWith('//') ? next : '/';
    } catch (err) {
      setError('login-error', err.message);
      busy(f, false);
    }
  });

  $('forgot-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    setError('forgot-error');
    busy(f, true);
    try {
      await post('/api/auth/forgot', { email: f.email.value });
      show('login-form');
      $('login-notice').textContent = 'If that email has an account, a reset link is on its way.';
      $('login-notice').classList.remove('hidden');
    } catch (err) {
      setError('forgot-error', err.message);
    }
    busy(f, false);
  });

  $('reset-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    setError('reset-error');
    if (f.password.value !== f.confirm.value) return setError('reset-error', 'Passwords do not match');
    busy(f, true);
    try {
      await post('/api/auth/reset', { token, password: f.password.value });
      location.href = '/';
    } catch (err) {
      setError('reset-error', err.message);
      busy(f, false);
    }
  });

  if (token) {
    show('reset-form');
    fetch('/api/auth/token?token=' + encodeURIComponent(token))
      .then((r) => r.json().then((d) => ({ ok: r.ok, d })))
      .then(({ ok, d }) => {
        if (!ok) {
          show('forgot-form');
          setError('forgot-error', d.error);
          return;
        }
        $('reset-title').textContent = d.isNew ? `Welcome, ${d.name}` : 'Choose a new password';
        $('reset-lead').textContent = d.isNew ? `Set a password for ${d.email} to get started.` : `For ${d.email}`;
      });
  }
})();
