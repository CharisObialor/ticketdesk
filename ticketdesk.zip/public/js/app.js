(function () {
  const { html, render, append, api, upload, timeAgo, fmtDate, fmtDuration, fileSize, cap, STATUS, statusBadge, priorityBadge, toast, modal, debounce } = L;

  const S = {
    user: null,
    app: null,
    staff: false,
    admin: false,
    counts: {},
    presence: null,
    socket: null,
    connected: false,
    view: null,
    staffList: null,
    companies: null,
    unread: 0,
  };
  const $ = (sel, root = document) => root.querySelector(sel);
  const $view = $('#view');
  const OPEN = ['open', 'in_progress', 'awaiting_client'];
  const IMG = /^image\/(png|jpe?g|gif|webp)$/;

  // ---------------------------------------------------------------- boot & routing

  async function boot() {
    const me = await api('GET', '/auth/me');
    S.user = me.user;
    S.app = me.app;
    S.staff = ['admin', 'agent'].includes(S.user.role);
    S.admin = S.user.role === 'admin';
    $('#who').textContent = S.user.name;
    $('#who-sub').textContent = S.staff ? cap(S.user.role) : S.user.company_name || '';
    connect();
    refreshCounts();
    window.addEventListener('hashchange', route);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) setUnread(0);
    });
    route();
  }

  let routeToken = 0;
  const stale = (token) => token !== routeToken;

  async function route() {
    $('#shell').classList.remove('nav-open');
    $('#modal-root').innerHTML = '';
    if (S.view && S.view.destroy) S.view.destroy();
    S.view = null;
    const [path, qs] = (location.hash.slice(1) || '/').split('?');
    const q = Object.fromEntries(new URLSearchParams(qs || ''));
    const parts = path.split('/').filter(Boolean);
    renderNav();

    let fn;
    if (!parts.length) fn = S.staff ? viewDashboard : () => viewTickets({ view: 'open' }, token);
    else if (parts[0] === 'tickets' && parts[1] === 'new') fn = viewNewTicket;
    else if (parts[0] === 'tickets' && parts[1]) fn = () => viewTicket(Number(parts[1]), token);
    else if (parts[0] === 'tickets') fn = viewTickets;
    else if (parts[0] === 'transcripts' && S.staff) fn = viewTranscripts;
    else if (parts[0] === 'companies' && S.staff) fn = viewCompanies;
    else if (parts[0] === 'users' && S.admin) fn = viewUsers;
    else if (parts[0] === 'profile') fn = viewProfile;
    else fn = async () => render($view, html`<div class="card empty">Page not found.</div>`);

    const token = ++routeToken;
    render($view, html`<div class="loading">Loading…</div>`);
    window.scrollTo(0, 0);
    try {
      const v = await fn(q, token);
      if (stale(token)) v && v.destroy && v.destroy();
      else S.view = v || null;
    } catch (err) {
      if (!stale(token)) render($view, html`<div class="card empty">${err.message}</div>`);
    }
  }

  function renderNav() {
    const c = S.counts;
    const cur = location.hash || '#/';
    const item = (href, icon, label, count, alert) =>
      html`<a href="#${href}" class="${cur === '#' + href ? 'active' : ''}"><span>${icon}</span><span>${label}</span>${
        count ? html`<span class="count ${alert ? 'alert' : ''}">${count}</span>` : ''
      }</a>`;
    const items = S.staff
      ? [
          item('/', '📊', 'Dashboard'),
          html`<div class="nav-label">Tickets</div>`,
          item('/tickets?view=open', '📥', 'All open', c.open),
          item('/tickets?view=mine', '🙋', 'Assigned to me', c.mine),
          item('/tickets?view=unassigned', '❔', 'Unassigned', c.unassigned, c.unassigned > 0),
          item('/tickets?view=escalated', '🚨', 'Escalated', c.escalated, c.escalated > 0),
          item('/tickets?view=resolved', '✅', 'Resolved'),
          item('/tickets/new', '➕', 'New ticket'),
          html`<div class="nav-label">Records</div>`,
          item('/transcripts', '🗂️', 'Transcripts'),
          item('/companies', '🏢', 'Companies'),
          S.admin ? item('/users', '👥', 'Users') : '',
          html`<div class="sep"></div>`,
          item('/profile', '⚙️', 'Profile'),
        ]
      : [
          item('/tickets?view=open', '📥', 'Open tickets', c.open),
          item('/tickets?view=mine', '🙋', 'Raised by me', c.mine),
          item('/tickets?view=resolved', '✅', 'Resolved'),
          item('/tickets/new', '➕', 'New ticket'),
          html`<div class="sep"></div>`,
          item('/profile', '⚙️', 'Profile'),
        ];
    render($('#nav'), items);
  }

  async function refreshCounts() {
    try {
      S.counts = await api('GET', '/tickets/counts');
      renderNav();
    } catch {}
  }
  const refreshCountsSoon = debounce(refreshCounts, 800);

  // ---------------------------------------------------------------- realtime

  function connect() {
    if (!window.io) return setConn();
    const s = (S.socket = window.io());
    let dropped = false;
    s.on('connect', () => {
      S.connected = true;
      setConn();
      if (dropped) {
        dropped = false;
        refreshCounts();
        S.view && S.view.onReconnect && S.view.onReconnect();
      }
    });
    s.on('disconnect', () => {
      S.connected = false;
      dropped = true;
      setConn();
    });
    s.on('connect_error', () => {
      S.connected = false;
      setConn();
    });
    s.on('presence', (p) => {
      S.presence = p;
      setConn();
      emitView('presence', p);
    });
    s.on('ticket:new', ({ ticket }) => {
      refreshCountsSoon();
      emitView('ticket:new', ticket);
      if (S.staff && ticket.created_by !== S.user.id) {
        alertUser(`New ticket #${ticket.id}`, `${ticket.company_name}: ${ticket.subject}`, ticket.id);
      }
    });
    s.on('ticket:update', ({ ticket }) => {
      refreshCountsSoon();
      emitView('ticket:update', ticket);
    });
    s.on('ticket:escalated', ({ ticket }) => {
      alertUser(`🚨 Ticket #${ticket.id} escalated`, ticket.subject, ticket.id, 'error');
    });
    s.on('message:new', ({ ticketId, message }) => {
      const handled = emitView('message:new', { ticketId, message });
      if (message.kind === 'message' && message.user_id !== S.user.id && !handled) {
        alertUser(`New reply on #${ticketId}`, `${message.user_name}: ${message.body.slice(0, 120)}`, ticketId);
      }
    });
    s.on('typing', (d) => emitView('typing', d));
  }

  function emitView(evt, payload) {
    const h = S.view && S.view.on && S.view.on[evt];
    return h ? !!h(payload) : false;
  }

  function setConn() {
    const el = $('#conn');
    let text = S.connected ? 'Live' : 'Reconnecting…';
    if (S.connected && S.staff && S.presence) {
      text = `${S.presence.total} online · ${S.presence.staff} staff, ${S.presence.clients} clients`;
    }
    render(el, html`<span class="dot ${S.connected ? 'on' : 'off'}"></span><span>${text}</span>`);
  }

  function setUnread(n) {
    S.unread = n;
    const base = S.app ? S.app.name : document.title.replace(/^\(\d+\) /, '');
    document.title = n ? `(${n}) ${base}` : base;
  }

  // Toast in the app, plus a desktop notification when the tab is in the background.
  function alertUser(title, body, ticketId, type) {
    const open = () => (location.hash = `#/tickets/${ticketId}`);
    toast(title, html`<div>${body}</div>`, { type, onClick: open });
    if (document.hidden) {
      setUnread(S.unread + 1);
      if ('Notification' in window && Notification.permission === 'granted') {
        const n = new Notification(title, { body, tag: `ticket-${ticketId}` });
        n.onclick = () => {
          window.focus();
          open();
          n.close();
        };
      }
    }
  }

  // ---------------------------------------------------------------- global events

  const globalActions = {
    logout: async () => {
      await api('POST', '/auth/logout').catch(() => {});
      location.href = '/login';
    },
    'toggle-nav': () => $('#shell').classList.toggle('nav-open'),
  };

  document.addEventListener('click', (e) => {
    const a = e.target.closest('[data-action]');
    if (a) {
      const name = a.dataset.action;
      const fn = globalActions[name] || (S.view && S.view.actions && S.view.actions[name]);
      if (fn) {
        e.preventDefault();
        fn(a, e);
      }
      return;
    }
    const row = e.target.closest('tr[data-href]');
    if (row && !e.target.closest('a, button, input, select')) location.hash = row.dataset.href;
  });
  document.addEventListener('change', (e) => S.view && S.view.onChange && S.view.onChange(e));

  // ---------------------------------------------------------------- shared bits

  function busy(btn, on, label) {
    if (!btn) return;
    if (on) {
      btn.dataset.label = btn.textContent;
      btn.textContent = label || 'Working…';
    } else if (btn.dataset.label) btn.textContent = btn.dataset.label;
    btn.disabled = on;
  }

  // Attachment picker: file input + drag & drop + paste, with removable chips.
  function filePicker({ input, chips, dropTarget, pasteTarget }) {
    const files = [];
    const max = S.app.upload;
    const draw = () =>
      render(
        chips,
        files.map(
          (f, i) => html`<span class="chip">📎 ${f.name} <span class="muted">${fileSize(f.size)}</span><button type="button" data-rm="${i}" aria-label="Remove">×</button></span>`
        )
      );
    const add = (list) => {
      for (const f of list) {
        if (files.length >= max.maxFiles) {
          toast('Too many files', html`Up to ${max.maxFiles} files per message.`, { type: 'error' });
          break;
        }
        if (f.size > max.maxMb * 1048576) {
          toast('File too large', html`${f.name} is over ${max.maxMb} MB.`, { type: 'error' });
          continue;
        }
        files.push(f);
      }
      draw();
    };
    input.addEventListener('change', () => {
      add(input.files);
      input.value = '';
    });
    chips.addEventListener('click', (e) => {
      const b = e.target.closest('[data-rm]');
      if (!b) return;
      files.splice(Number(b.dataset.rm), 1);
      draw();
    });
    if (dropTarget) {
      dropTarget.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropTarget.classList.add('drag-over');
      });
      dropTarget.addEventListener('dragleave', (e) => {
        if (!dropTarget.contains(e.relatedTarget)) dropTarget.classList.remove('drag-over');
      });
      dropTarget.addEventListener('drop', (e) => {
        e.preventDefault();
        dropTarget.classList.remove('drag-over');
        add(e.dataTransfer.files);
      });
    }
    if (pasteTarget) {
      pasteTarget.addEventListener('paste', (e) => {
        const pasted = [...(e.clipboardData?.files || [])];
        if (pasted.length) {
          e.preventDefault();
          add(pasted);
        }
      });
    }
    return {
      files,
      clear() {
        files.length = 0;
        draw();
      },
    };
  }

  const opt = (value, label, current) => html`<option value="${value}" ${String(value) === String(current ?? '') ? 'selected' : ''}>${label}</option>`;

  async function ensureCompanies(force) {
    if (!S.companies || force) S.companies = (await api('GET', '/companies')).companies;
    return S.companies;
  }

  // ---------------------------------------------------------------- dashboard

  async function viewDashboard(q, token) {
    let days = Number(q.days) || 30;
    let m = await api('GET', `/metrics?days=${days}`);
    if (stale(token)) return;

    const kpi = (label, value, sub, alert, id) =>
      html`<div class="card kpi ${alert ? 'alert' : ''}" ${id ? html`id="${id}"` : ''}><div class="label">${label}</div><div class="value">${value}</div><div class="sub">${sub || ''}</div></div>`;
    const bars = (list) => {
      const max = Math.max(1, ...list.map((r) => r.total));
      return list.length
        ? html`<ul class="bars">${list.map(
            (r) =>
              html`<li><span class="name" title="${r.name}">${r.name}</span><span class="track"><span class="fill" style="width:${Math.round((r.total / max) * 100)}%"></span></span><span class="val">${r.total}</span></li>`
          )}</ul>`
        : html`<div class="muted small">No tickets in this period.</div>`;
    };
    const onlineList = (p) =>
      p && p.users.length
        ? p.users.map(
            (u) =>
              html`<div><span class="dot on"></span><b>${u.name}</b><span class="muted small">${u.role === 'client' ? u.company_name || 'Client' : cap(u.role)}</span></div>`
          )
        : html`<div class="muted small">Nobody else is online.</div>`;

    function draw() {
      const k = m.kpis;
      const slaTotal = k.slaMet + k.slaMissed;
      render(
        $view,
        html`
        <div class="page-head">
          <h1>Dashboard</h1><span class="spacer"></span>
          <select id="days" style="width:auto">${[7, 30, 90, 365].map((d) => opt(d, `Last ${d} days`, days))}</select>
          <a class="btn primary" href="#/tickets/new">New ticket</a>
        </div>
        <div class="kpis">
          ${kpi('Tickets raised', k.raised, `${k.messages} messages exchanged`)}
          ${kpi('Problems solved', k.resolved, `in the last ${days} days`)}
          ${kpi('Open now', k.open, `${k.unassigned} unassigned · ${k.urgentOpen} urgent`, false)}
          ${kpi('Escalated (open)', k.escalatedOpen, `${k.escalationsInPeriod} escalations in period`, k.escalatedOpen > 0)}
          ${kpi('Avg first response', fmtDuration(k.avgFirstResponseMin), `median ${fmtDuration(k.medianFirstResponseMin)}`)}
          ${kpi('Avg time to resolve', fmtDuration(k.avgResolutionMin), 'from open to resolved')}
          ${kpi('SLA met', slaTotal ? Math.round((k.slaMet / slaTotal) * 100) + '%' : '-', `${k.slaMet} met · ${k.slaMissed} missed`, slaTotal && k.slaMissed / slaTotal > 0.2)}
          ${kpi('Online now', m.online.total, `${m.online.staff} staff · ${m.online.clients} clients`, false, 'kpi-online')}
        </div>
        <div class="grid-2">
          <div class="card">
            <div class="card-head"><h2>Raised vs solved</h2><span class="spacer"></span>
              <div class="legend"><span><i class="ca"></i>Raised</span><span><i class="cb"></i>Solved</span></div></div>
            <div class="card-pad">${chart(m.series, m.weekly)}</div>
          </div>
          <div class="card">
            <div class="card-head"><h2>Tickets by status</h2></div>
            <div class="card-pad">${Object.keys(STATUS).map(
              (s) => html`<div class="statline"><span>${statusBadge(s)}</span><b>${m.status[s] || 0}</b></div>`
            )}</div>
          </div>
        </div>
        <div class="grid-3">
          <div class="card"><div class="card-head"><h2>By priority</h2></div><div class="card-pad">${bars(m.byPriority)}</div></div>
          <div class="card"><div class="card-head"><h2>By category</h2></div><div class="card-pad">${bars(m.byCategory)}</div></div>
          <div class="card"><div class="card-head"><h2>By company</h2></div><div class="card-pad">${bars(m.byCompany)}</div></div>
        </div>
        <div class="grid-2">
          <div class="card">
            <div class="card-head"><h2>Team workload</h2></div>
            <div class="table-wrap"><table class="list">
              <thead><tr><th>Staff</th><th class="num">Open</th><th class="num">Escalated</th><th class="num">Solved (${days}d)</th><th class="hide-sm">Last seen</th></tr></thead>
              <tbody>${m.agents.map(
                (a) => html`<tr><td><span class="dot ${a.online ? 'on' : ''}"></span> ${a.name} <span class="muted small">${cap(a.role)}</span></td>
                  <td class="num">${a.open}</td><td class="num">${a.escalated}</td><td class="num">${a.resolved}</td>
                  <td class="hide-sm muted">${a.online ? 'Online' : a.last_seen_at ? timeAgo(a.last_seen_at) : '-'}</td></tr>`
              )}</tbody></table></div>
          </div>
          <div class="card">
            <div class="card-head"><h2>Who's online</h2><span class="spacer"></span><span class="badge" id="online-count">${m.online.total}</span></div>
            <div class="card-pad online-list" id="online-list">${onlineList(m.online)}</div>
          </div>
        </div>
        <div class="card">
          <div class="card-head"><h2>Recent activity</h2><span class="spacer"></span><a href="#/tickets?view=all" class="small">All tickets →</a></div>
          <div class="table-wrap"><table class="list"><tbody>${m.recent.map(ticketRow)}</tbody></table></div>
        </div>`
      );
    }
    draw();

    const reload = debounce(async () => {
      const next = await api('GET', `/metrics?days=${days}`).catch(() => null);
      if (next && S.view === view) {
        m = next;
        draw();
      }
    }, 1500);

    const view = {
      onChange(e) {
        if (e.target.id !== 'days') return;
        days = Number(e.target.value);
        history.replaceState(null, '', `#/?days=${days}`);
        reload();
      },
      onReconnect: reload,
      on: {
        'ticket:new': reload,
        'ticket:update': reload,
        presence(p) {
          m.online = p;
          const tile = $('#kpi-online');
          if (tile) {
            $('.value', tile).textContent = p.total;
            $('.sub', tile).textContent = `${p.staff} staff · ${p.clients} clients`;
          }
          const list = $('#online-list');
          if (list) render(list, onlineList(p));
          const c = $('#online-count');
          if (c) c.textContent = p.total;
        },
      },
    };
    return view;
  }

  function chart(series, weekly) {
    const W = 640;
    const H = 220;
    const pl = 30;
    const pr = 6;
    const pt = 10;
    const pb = 24;
    const iw = W - pl - pr;
    const ih = H - pt - pb;
    const peak = Math.max(4, ...series.map((s) => Math.max(s.created, s.resolved)));
    const top = Math.ceil(peak / 4) * 4;
    const n = series.length;
    const gw = iw / n;
    const bw = Math.max(1.5, Math.min(14, gw * 0.36));
    const label = (key) =>
      new Date(key + 'T00:00:00Z').toLocaleDateString(undefined, { month: 'short', day: 'numeric', timeZone: 'UTC' });
    let out = '';
    for (let i = 0; i <= 4; i++) {
      const y = pt + ih - (ih * i) / 4;
      out += `<line class="grid" x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}"/><text x="${pl - 6}" y="${y + 4}" text-anchor="end">${(top * i) / 4}</text>`;
    }
    const every = Math.ceil(n / 8);
    series.forEach((s, i) => {
      const x = pl + gw * i + gw / 2;
      const hc = (ih * s.created) / top;
      const hr = (ih * s.resolved) / top;
      out += `<g><title>${weekly ? 'Week of ' : ''}${label(s.key)}: ${s.created} raised, ${s.resolved} solved</title>
        <rect class="hit" x="${pl + gw * i}" y="${pt}" width="${gw}" height="${ih}"/>
        <rect class="ca" x="${x - bw - 1}" y="${pt + ih - hc}" width="${bw}" height="${hc}" rx="2"/>
        <rect class="cb" x="${x + 1}" y="${pt + ih - hr}" width="${bw}" height="${hr}" rx="2"/></g>`;
      if (i % every === 0) out += `<text x="${x}" y="${H - 6}" text-anchor="middle">${label(s.key)}</text>`;
    });
    // Only numbers and locale date strings go into this markup.
    return L.raw(`<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Tickets raised and solved over time">${out}</svg>`);
  }

  // ---------------------------------------------------------------- ticket list

  function ticketRow(t) {
    return html`<tr class="click" data-href="#/tickets/${t.id}">
      <td class="muted" style="width:60px">#${t.id}</td>
      <td><div class="subject">${t.subject}</div>
        <div class="muted small">${S.staff ? html`${t.company_name} · ` : ''}${t.creator_name || 'Unknown'} · ${t.category}</div></td>
      <td>${priorityBadge(t.priority)}</td>
      <td>${statusBadge(t.status)} ${t.escalated ? html`<span class="badge esc">Escalated</span>` : ''}</td>
      <td class="hide-sm">${t.assignee_name || html`<span class="muted">Unassigned</span>`}</td>
      <td class="hide-sm muted" title="${fmtDate(t.last_activity_at)}">${timeAgo(t.last_activity_at)}</td>
    </tr>`;
  }

  async function viewTickets(q, token) {
    const state = { view: q.view || 'open', q: q.q || '', priority: q.priority || '', company_id: q.company_id || '' };
    if (S.staff) await ensureCompanies();
    if (stale(token)) return;

    const tabs = S.staff
      ? [['open', 'All open', 'open'], ['mine', 'Assigned to me', 'mine'], ['unassigned', 'Unassigned', 'unassigned'], ['escalated', 'Escalated', 'escalated'], ['resolved', 'Resolved'], ['all', 'All']]
      : [['open', 'Open', 'open'], ['mine', 'Raised by me', 'mine'], ['resolved', 'Resolved'], ['all', 'All']];
    const titles = { open: 'Open tickets', mine: S.staff ? 'Assigned to me' : 'Raised by me', unassigned: 'Unassigned', escalated: 'Escalated', resolved: 'Resolved', all: 'All tickets' };

    render(
      $view,
      html`
      <div class="page-head"><h1>${titles[state.view] || 'Tickets'}</h1><span class="spacer"></span><a class="btn primary" href="#/tickets/new">New ticket</a></div>
      <div class="tabs">${tabs.map(
        ([v, label, countKey]) =>
          html`<a href="#/tickets?view=${v}" class="${state.view === v ? 'active' : ''}">${label}${
            countKey && S.counts[countKey] ? html`<span class="n">${S.counts[countKey]}</span>` : ''
          }</a>`
      )}</div>
      <div class="toolbar">
        <input type="search" id="q" placeholder="Search subject, company, #id…" value="${state.q}">
        <select id="f-priority"><option value="">Any priority</option>${S.app.priorities.map((p) => opt(p, cap(p), state.priority))}</select>
        ${S.staff
          ? html`<select id="f-company"><option value="">All companies</option>${S.companies.map((c) => opt(c.id, c.name, state.company_id))}</select>`
          : ''}
      </div>
      <div class="card"><div class="table-wrap"><table class="list">
        <thead><tr><th>#</th><th>Subject</th><th>Priority</th><th>Status</th><th class="hide-sm">Assignee</th><th class="hide-sm">Activity</th></tr></thead>
        <tbody id="rows"><tr><td colspan="6" class="empty">Loading…</td></tr></tbody>
      </table></div><div id="more" class="card-pad hidden" style="text-align:center"><button class="btn" data-action="more">Load more</button></div></div>`
    );

    let page = 1;
    async function load(reset) {
      if (reset) page = 1;
      const params = new URLSearchParams({ view: state.view, page });
      for (const k of ['q', 'priority', 'company_id']) if (state[k]) params.set(k, state[k]);
      const d = await api('GET', `/tickets?${params}`);
      if (S.view !== view && S.view !== null) return;
      const rows = $('#rows');
      if (!rows) return;
      if (reset) render(rows, d.tickets.length ? d.tickets.map(ticketRow) : html`<tr><td colspan="6" class="empty">No tickets here. 🎉</td></tr>`);
      else append(rows, d.tickets.map(ticketRow));
      $('#more').classList.toggle('hidden', !d.hasMore);
    }

    function syncUrl() {
      const p = new URLSearchParams();
      for (const k of ['view', 'q', 'priority', 'company_id']) if (state[k]) p.set(k, state[k]);
      history.replaceState(null, '', `#/tickets?${p}`);
    }

    $('#q').addEventListener(
      'input',
      debounce((e) => {
        state.q = e.target.value.trim();
        syncUrl();
        load(true);
      }, 300)
    );

    const reload = debounce(() => load(true), 1000);
    const view = {
      actions: {
        more: () => {
          page++;
          load(false);
        },
      },
      onChange(e) {
        if (e.target.id === 'f-priority') state.priority = e.target.value;
        else if (e.target.id === 'f-company') state.company_id = e.target.value;
        else return;
        syncUrl();
        load(true);
      },
      onReconnect: reload,
      on: { 'ticket:new': reload, 'ticket:update': reload },
    };
    await load(true);
    return view;
  }

  // ---------------------------------------------------------------- new ticket

  async function viewNewTicket(q, token) {
    if (S.staff) await ensureCompanies();
    if (stale(token)) return;
    const a = S.app;
    render(
      $view,
      html`
      <div class="page-head"><h1>New ticket</h1></div>
      <form class="card card-pad" id="nt" style="max-width:760px">
        <p class="error-text hidden" id="nt-error"></p>
        ${S.staff
          ? html`<div class="row">
              <label class="field"><span>Company</span><select name="company_id" required><option value="">Choose a company…</option>${S.companies
                .filter((c) => c.is_active)
                .map((c) => opt(c.id, c.name, q.company_id))}</select></label>
              <label class="field"><span>Requester <span class="muted">(optional)</span></span><select name="requester_id"><option value="">Me (on their behalf)</option></select></label>
            </div>`
          : ''}
        <label class="field"><span>Subject</span><input name="subject" maxlength="255" required placeholder="Short summary of the problem"></label>
        <div class="row">
          <label class="field"><span>Category</span><select name="category">${a.categories.map((c) => opt(c, c, 'General'))}</select></label>
          <label class="field"><span>Priority</span><select name="priority">${a.priorities.map((p) => opt(p, cap(p), 'normal'))}</select></label>
        </div>
        <label class="field"><span>Description</span><textarea name="body" rows="8" required placeholder="What's happening? Include steps to reproduce, links, and what you expected."></textarea></label>
        <label class="field"><span>Attachments <span class="muted">(up to ${a.upload.maxFiles} files, ${a.upload.maxMb} MB each)</span></span>
          <label class="dropzone" id="drop">Drop files here, paste screenshots, or <u>browse</u><input type="file" multiple hidden id="nt-files"></label>
          <div class="chips" id="nt-chips"></div>
        </label>
        <div class="form-actions"><a class="btn" href="#/tickets">Cancel</a><button class="btn primary" type="submit">Submit ticket</button></div>
      </form>`
    );
    const form = $('#nt');
    const picker = filePicker({ input: $('#nt-files'), chips: $('#nt-chips'), dropTarget: $('#drop'), pasteTarget: form });

    async function loadRequesters(companyId) {
      const sel = form.requester_id;
      if (!sel) return;
      const users = companyId ? (await api('GET', `/users?company_id=${companyId}`)).users.filter((u) => u.is_active) : [];
      render(sel, [html`<option value="">Me (on their behalf)</option>`, users.map((u) => opt(u.id, `${u.name} (${u.email})`))]);
    }
    if (S.staff && q.company_id) loadRequesters(q.company_id);

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type=submit]');
      const err = $('#nt-error');
      err.classList.add('hidden');
      const fd = new FormData();
      for (const k of ['company_id', 'requester_id', 'subject', 'category', 'priority', 'body']) if (form[k]) fd.append(k, form[k].value);
      picker.files.forEach((f) => fd.append('files', f));
      busy(btn, true, 'Submitting…');
      try {
        const d = await upload('/tickets', fd, (p) => picker.files.length && (btn.textContent = `Uploading ${Math.round(p * 100)}%`));
        refreshCounts();
        toast('Ticket submitted', html`#${d.ticket.id} - our team has been notified.`);
        location.hash = `#/tickets/${d.ticket.id}`;
      } catch (ex) {
        err.textContent = ex.message;
        err.classList.remove('hidden');
        busy(btn, false);
      }
    });

    return {
      onChange(e) {
        if (e.target.name === 'company_id' && e.target.form === form) loadRequesters(e.target.value);
      },
    };
  }

  // ---------------------------------------------------------------- ticket detail / chat

  function attachmentHtml(a) {
    return IMG.test(a.mime)
      ? html`<a href="/api/files/${a.id}" target="_blank" rel="noopener" title="${a.original_name}"><img src="/api/files/${a.id}" alt="${a.original_name}" loading="lazy"></a>`
      : html`<a class="file" href="/api/files/${a.id}?download=1"><span>📎 ${a.original_name}</span><span class="muted">${fileSize(a.size)}</span></a>`;
  }

  function messageHtml(m) {
    if (m.kind === 'system') {
      return html`<div class="msg sys" data-id="${m.id}" title="${fmtDate(m.created_at)}">${m.user_name ? html`<b>${m.user_name}</b> · ` : ''}${m.body} · ${timeAgo(m.created_at)}</div>`;
    }
    const mine = m.user_id === S.user.id;
    const fromStaff = m.user_role && m.user_role !== 'client';
    const showBody = !(m.body === '(attachment)' && m.attachments.length);
    return html`<div class="msg ${mine ? 'mine' : ''} ${m.is_internal ? 'note' : ''}" data-id="${m.id}">
      <div class="meta"><b>${mine ? 'You' : m.user_name || 'Deleted user'}</b>
        ${fromStaff && !S.staff ? html`<span class="badge">Support team</span>` : ''}
        ${S.staff && m.user_role === 'client' ? html`<span class="badge">Client</span>` : ''}
        ${m.is_internal ? html`<span class="badge">🔒 Internal note</span>` : ''}
        <span title="${fmtDate(m.created_at)}">${timeAgo(m.created_at)}</span></div>
      ${showBody ? html`<div class="bubble">${m.body}</div>` : ''}
      ${m.attachments.length ? html`<div class="attachments">${m.attachments.map(attachmentHtml)}</div>` : ''}
    </div>`;
  }

  async function viewTicket(id, token) {
    const [d] = await Promise.all([api('GET', `/tickets/${id}`), S.staff && !S.staffList ? api('GET', '/staff').then((r) => (S.staffList = r.staff)) : null]);
    if (stale(token)) return;
    let t = d.ticket;
    let transcripts = d.transcripts;
    const files = [];
    const seen = new Set();

    render(
      $view,
      html`
      <div class="page-head">
        <div style="min-width:0">
          <div class="ticket-title"><h1>${t.subject}</h1><span id="title-badges"></span></div>
          <div class="muted small">#${t.id} · ${t.company_name} · opened by ${t.creator_name || 'unknown'} ${timeAgo(t.created_at)}</div>
        </div>
        <span class="spacer"></span><a class="btn" href="#/tickets">← Tickets</a>
      </div>
      <div class="ticket-layout">
        <div class="card thread-card" id="thread-card">
          <div class="thread" id="thread"></div>
          <div class="typing" id="typing"></div>
          <div id="composer-slot"></div>
        </div>
        <div class="side" id="side"></div>
      </div>`
    );
    const thread = $('#thread');

    function addMessage(m, forceScroll) {
      if (seen.has(m.id)) return;
      seen.add(m.id);
      const nearBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 120;
      append(thread, messageHtml(m));
      files.push(...m.attachments);
      if (nearBottom || forceScroll) thread.scrollTop = thread.scrollHeight;
    }
    d.messages.forEach((m) => addMessage(m));
    thread.scrollTop = thread.scrollHeight;

    // -- composer
    let picker = null;
    function drawComposer() {
      const slot = $('#composer-slot');
      if (!S.staff && t.status === 'closed') {
        if (!$('#closed-note')) render(slot, html`<div class="composer muted" id="closed-note">This ticket is closed. Need more help? <a href="#/tickets/new">Open a new ticket</a>.</div>`);
        picker = null;
        return;
      }
      if ($('#composer')) return;
      render(
        slot,
        html`<form class="composer" id="composer">
          <textarea name="body" placeholder="Write a reply…  (Ctrl+Enter to send)"></textarea>
          <div class="chips" id="chips"></div>
          <div class="composer-bar">
            <label class="btn sm ghost">📎 Attach<input type="file" multiple hidden id="file-input"></label>
            ${S.staff ? html`<label class="check small"><input type="checkbox" name="internal"> Internal note (staff only)</label>` : ''}
            <span class="spacer"></span><span class="muted small" id="send-progress"></span>
            <button class="btn primary sm" type="submit">Send</button>
          </div>
        </form>`
      );
      const form = $('#composer');
      picker = filePicker({ input: $('#file-input'), chips: $('#chips'), dropTarget: $('#thread-card'), pasteTarget: form.body });
      form.body.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
          e.preventDefault();
          form.requestSubmit();
        }
      });
      form.body.addEventListener('input', () => {
        form.body.style.height = 'auto';
        form.body.style.height = Math.min(260, form.body.scrollHeight) + 'px';
        typing(true);
      });
      form.addEventListener('submit', send);
    }

    // Typing indicator: never broadcast while writing an internal note.
    let typingSentAt = 0;
    let typingStop;
    function typing(on) {
      const form = $('#composer');
      if (!S.socket || (form && form.internal && form.internal.checked)) return;
      clearTimeout(typingStop);
      if (on) {
        if (Date.now() - typingSentAt > 2500) {
          S.socket.emit('typing', { ticketId: t.id, typing: true });
          typingSentAt = Date.now();
        }
        typingStop = setTimeout(() => typing(false), 3000);
      } else {
        S.socket.emit('typing', { ticketId: t.id, typing: false });
        typingSentAt = 0;
      }
    }

    async function send(e) {
      e.preventDefault();
      const form = e.target;
      const body = form.body.value.trim();
      if (!body && !picker.files.length) return;
      const btn = form.querySelector('button[type=submit]');
      const fd = new FormData();
      fd.append('body', body);
      if (form.internal && form.internal.checked) fd.append('internal', '1');
      picker.files.forEach((f) => fd.append('files', f));
      busy(btn, true, 'Sending…');
      const progress = $('#send-progress');
      try {
        const r = await upload(`/tickets/${t.id}/messages`, fd, (p) => picker.files.length && (progress.textContent = `Uploading ${Math.round(p * 100)}%`));
        addMessage(r.message, true);
        t = r.ticket;
        drawSide();
        form.body.value = '';
        form.body.style.height = '';
        picker.clear();
        typing(false);
      } catch (ex) {
        toast('Message not sent', html`${ex.message}`, { type: 'error' });
      }
      progress.textContent = '';
      busy(btn, false);
      form.body.focus();
    }

    // -- side panel
    function drawSide() {
      render(
        $('#title-badges'),
        html`${statusBadge(t.status)} ${priorityBadge(t.priority)} ${t.escalated ? html`<span class="badge esc">Escalated L${t.escalation_level}</span>` : ''}`
      );
      const isOpen = OPEN.includes(t.status);
      const sel = (field, options, current) => html`<select data-field="${field}">${options.map(([v, l]) => opt(v, l, current))}</select>`;
      const details = S.staff
        ? html`
          <dt>Status</dt><dd>${sel('status', S.app.statuses.map((s) => [s.value, s.label]), t.status)}</dd>
          <dt>Priority</dt><dd>${sel('priority', S.app.priorities.map((p) => [p, cap(p)]), t.priority)}</dd>
          <dt>Category</dt><dd>${sel('category', S.app.categories.map((c) => [c, c]), t.category)}</dd>
          <dt>Assignee</dt><dd>${sel('assigned_to', [['', 'Unassigned'], ...S.staffList.map((s) => [s.id, s.name])], t.assigned_to)}</dd>`
        : html`
          <dt>Status</dt><dd>${statusBadge(t.status)}</dd>
          <dt>Priority</dt><dd>${priorityBadge(t.priority)}</dd>
          <dt>Category</dt><dd>${t.category}</dd>
          <dt>Handled by</dt><dd>${t.assignee_name || html`<span class="muted">Not yet assigned</span>`}</dd>`;

      const actions = S.staff
        ? [
            t.assigned_to !== S.user.id ? html`<button class="btn" data-action="take">🙋 Assign to me</button>` : '',
            t.escalated
              ? html`<button class="btn" data-action="deescalate">Clear escalation</button>`
              : html`<button class="btn warn" data-action="escalate">🚨 Escalate</button>`,
            isOpen ? html`<button class="btn" data-action="set-status" data-status="resolved">✅ Mark resolved</button>` : '',
            t.status !== 'closed' ? html`<button class="btn" data-action="set-status" data-status="closed">Close ticket</button>` : html`<button class="btn" data-action="set-status" data-status="open">Reopen</button>`,
          ]
        : [
            isOpen ? html`<button class="btn" data-action="set-status" data-status="resolved">✅ My problem is solved</button>` : '',
            t.status === 'resolved' ? html`<button class="btn" data-action="set-status" data-status="open">Reopen ticket</button>` : '',
            isOpen && !t.escalated ? html`<button class="btn warn" data-action="escalate">🚨 Escalate</button>` : '',
            t.escalated ? html`<div class="small muted">This ticket has been escalated to senior staff.</div>` : '',
          ];

      render(
        $('#side'),
        html`
        <div class="card card-pad"><dl>
          ${details}
          <dt>Company</dt><dd>${t.company_name}</dd>
          <dt>Requester</dt><dd>${t.creator_name || '-'}${S.staff && t.creator_email ? html`<div class="small"><a href="mailto:${t.creator_email}">${t.creator_email}</a></div>` : ''}</dd>
          <dt>Opened</dt><dd>${fmtDate(t.created_at)}</dd>
          <dt>First reply</dt><dd>${t.first_response_at ? fmtDate(t.first_response_at) : html`<span class="muted">Waiting</span>`}</dd>
          ${t.resolved_at ? html`<dt>Resolved</dt><dd>${fmtDate(t.resolved_at)}</dd>` : ''}
        </dl></div>
        <div class="card card-pad"><div class="stack">${actions}</div></div>
        <div class="card card-pad">
          <h3 style="margin-bottom:8px">Export conversation</h3>
          <div class="stack">
            <div class="row" style="flex-direction:row;gap:6px">
              <a class="btn sm" href="/api/tickets/${t.id}/export?format=html" download>HTML / PDF</a>
              <a class="btn sm" href="/api/tickets/${t.id}/export?format=txt" download>Text</a>
              <a class="btn sm" href="/api/tickets/${t.id}/export?format=json" download>JSON</a>
            </div>
            ${S.staff
              ? html`<div class="muted small">Exports include internal notes. Open the HTML file and print to save as PDF.</div>
                <button class="btn sm" data-action="archive">🗂️ Save transcript to archive</button>
                ${transcripts.length
                  ? html`<div class="small">${transcripts.map(
                      (tr) => html`<div class="statline"><a href="/api/transcripts/${tr.id}/download">${fmtDate(tr.created_at)}</a><span class="muted">${tr.reason} · ${tr.message_count} msgs</span></div>`
                    )}</div>`
                  : html`<div class="muted small">No archived transcripts yet. One is saved automatically when the ticket is resolved or closed.</div>`}`
              : html`<div class="muted small">Download a copy of this conversation for your records.</div>`}
          </div>
        </div>
        ${files.length
          ? html`<div class="card card-pad"><h3 style="margin-bottom:8px">Files (${files.length})</h3><div class="attachments">${files.map(
              (a) => html`<a class="file" href="/api/files/${a.id}?download=1"><span>📎 ${a.original_name}</span><span class="muted">${fileSize(a.size)}</span></a>`
            )}</div></div>`
          : ''}`
      );
      drawComposer();
    }
    drawSide();

    async function patch(body) {
      try {
        t = (await api('PATCH', `/tickets/${t.id}`, body)).ticket;
        drawSide();
        refreshCountsSoon();
      } catch (ex) {
        toast('Update failed', html`${ex.message}`, { type: 'error' });
        drawSide();
      }
    }

    async function refetch() {
      const d2 = await api('GET', `/tickets/${t.id}`).catch(() => null);
      if (!d2 || S.view !== view) return;
      d2.messages.forEach((m) => addMessage(m));
      t = d2.ticket;
      transcripts = d2.transcripts;
      drawSide();
    }
    const refetchSoon = debounce(refetch, 1200);

    let typingClear;
    const view = {
      actions: {
        take: () => patch({ assigned_to: S.user.id }),
        deescalate: () => patch({ escalate: false }),
        'set-status': (el) => patch({ status: el.dataset.status }),
        escalate() {
          const m = modal(html`
            <h2 style="margin-bottom:6px">Escalate ticket #${t.id}</h2>
            <p class="muted" style="margin-top:0">${S.staff ? 'Admins will be alerted by email immediately.' : 'Our senior team will be alerted immediately.'}</p>
            <form id="esc-form">
              <label class="field"><span>Reason</span><textarea name="reason" rows="3" maxlength="500" placeholder="Why does this need urgent attention?"></textarea></label>
              <div class="form-actions"><button type="button" class="btn" data-close>Cancel</button><button class="btn warn" type="submit">Escalate</button></div>
            </form>`);
          $('#esc-form', m.el).addEventListener('submit', async (e) => {
            e.preventDefault();
            busy(e.target.querySelector('[type=submit]'), true);
            await patch({ escalate: true, reason: e.target.reason.value });
            m.close();
          });
        },
        async archive(el) {
          busy(el, true, 'Saving…');
          try {
            await api('POST', `/tickets/${t.id}/archive`);
            toast('Transcript saved', html`Stored in the transcripts archive.`);
            await refetch();
          } catch (ex) {
            toast('Could not save transcript', html`${ex.message}`, { type: 'error' });
            busy(el, false);
          }
        },
      },
      onChange(e) {
        const field = e.target.dataset.field;
        if (field && e.target.closest('#side')) patch({ [field]: e.target.value || null });
        if (e.target.name === 'internal' && e.target.closest('#composer')) {
          e.target.closest('#composer').classList.toggle('internal', e.target.checked);
        }
      },
      onReconnect: refetch,
      on: {
        'message:new'({ ticketId, message }) {
          if (ticketId !== t.id) return false;
          addMessage(message);
          $('#typing').textContent = '';
          if (document.hidden && message.user_id !== S.user.id && message.kind === 'message') {
            alertUser(`New reply on #${t.id}`, `${message.user_name}: ${message.body.slice(0, 120)}`, t.id);
          }
          return true;
        },
        'ticket:update'(ticket) {
          if (ticket.id !== t.id) return;
          t = ticket;
          drawSide();
          if (S.staff && ['resolved', 'closed'].includes(t.status)) refetchSoon();
        },
        typing(d) {
          if (d.ticketId !== t.id || d.userId === S.user.id) return;
          const el = $('#typing');
          el.textContent = d.typing ? `${d.name} is typing…` : '';
          clearTimeout(typingClear);
          if (d.typing) typingClear = setTimeout(() => (el.textContent = ''), 6000);
        },
      },
      destroy() {
        clearTimeout(typingStop);
        clearTimeout(typingClear);
      },
    };
    return view;
  }

  // ---------------------------------------------------------------- transcripts

  async function viewTranscripts(q, token) {
    render(
      $view,
      html`
      <div class="page-head"><h1>Transcripts archive</h1><span class="spacer"></span></div>
      <p class="muted" style="margin-top:-8px">Full conversation records, saved automatically when tickets are resolved or closed, or manually from a ticket.</p>
      <div class="toolbar"><input type="search" id="tq" placeholder="Search by subject, company or #id" value="${q.q || ''}"></div>
      <div class="card"><div class="table-wrap"><table class="list">
        <thead><tr><th>Ticket</th><th>Company</th><th>Saved</th><th class="hide-sm">Reason</th><th class="num hide-sm">Messages</th><th class="num hide-sm">Size</th><th></th></tr></thead>
        <tbody id="tr-rows"></tbody></table></div></div>`
    );
    async function load(term) {
      const d = await api('GET', `/transcripts${term ? '?q=' + encodeURIComponent(term) : ''}`);
      const rows = $('#tr-rows');
      if (!rows) return;
      render(
        rows,
        d.transcripts.length
          ? d.transcripts.map(
              (r) => html`<tr>
                <td><a href="#/tickets/${r.ticket_id}">#${r.ticket_id}</a> ${r.subject}</td>
                <td>${r.company_name}</td>
                <td title="${fmtDate(r.created_at)}">${timeAgo(r.created_at)}${r.created_by_name ? html`<div class="muted small">by ${r.created_by_name}</div>` : ''}</td>
                <td class="hide-sm">${cap(r.reason)}</td>
                <td class="num hide-sm">${r.message_count}</td>
                <td class="num hide-sm">${fileSize(r.size)}</td>
                <td><a class="btn sm" href="/api/transcripts/${r.id}/download">Download</a></td></tr>`
            )
          : html`<tr><td colspan="7" class="empty">No transcripts yet.</td></tr>`
      );
    }
    await load(q.q);
    if (stale(token)) return;
    $('#tq').addEventListener('input', debounce((e) => load(e.target.value.trim()), 300));
    return {};
  }

  // ---------------------------------------------------------------- companies

  async function viewCompanies(q, token) {
    await ensureCompanies(true);
    if (stale(token)) return;
    const draw = () =>
      render(
        $view,
        html`
        <div class="page-head"><h1>Companies</h1><span class="spacer"></span>${S.admin ? html`<button class="btn primary" data-action="new-company">Add company</button>` : ''}</div>
        <div class="card"><div class="table-wrap"><table class="list">
          <thead><tr><th>Company</th><th class="hide-sm">Email domain</th><th class="num">Users</th><th class="num">Open</th><th class="num">Total</th><th>Status</th><th></th></tr></thead>
          <tbody>${S.companies.length
            ? S.companies.map(
                (c) => html`<tr>
                  <td><b>${c.name}</b>${c.notes ? html`<div class="muted small">${c.notes}</div>` : ''}</td>
                  <td class="hide-sm muted">${c.email_domain || '-'}</td>
                  <td class="num"><a href="#/users?company_id=${c.id}">${c.user_count}</a></td>
                  <td class="num">${c.open_tickets}</td>
                  <td class="num"><a href="#/tickets?view=all&company_id=${c.id}">${c.total_tickets}</a></td>
                  <td>${c.is_active ? html`<span class="badge s-resolved">Active</span>` : html`<span class="badge">Disabled</span>`}</td>
                  <td style="text-align:right;white-space:nowrap">
                    <a class="btn sm" href="#/tickets/new?company_id=${c.id}">New ticket</a>
                    ${S.admin ? html`<button class="btn sm" data-action="edit-company" data-id="${c.id}">Edit</button>` : ''}</td></tr>`
              )
            : html`<tr><td colspan="7" class="empty">No companies yet. Add your first client company to start inviting their users.</td></tr>`}</tbody>
        </table></div></div>`
      );
    draw();

    function form(c = {}) {
      const m = modal(html`
        <h2 style="margin-bottom:14px">${c.id ? 'Edit company' : 'Add company'}</h2>
        <form id="co-form">
          <p class="error-text hidden" id="co-err"></p>
          <label class="field"><span>Name</span><input name="name" required value="${c.name || ''}"></label>
          <label class="field"><span>Email domain <span class="muted">(optional, e.g. acme.com)</span></span><input name="email_domain" value="${c.email_domain || ''}"></label>
          <label class="field"><span>Notes <span class="muted">(staff only)</span></span><textarea name="notes" rows="3">${c.notes || ''}</textarea></label>
          ${c.id ? html`<label class="check field"><input type="checkbox" name="is_active" ${c.is_active ? 'checked' : ''}> Active (disabled companies' users can't sign in)</label>` : ''}
          <div class="form-actions"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" type="submit">Save</button></div>
        </form>`);
      $('#co-form', m.el).addEventListener('submit', async (e) => {
        e.preventDefault();
        const f = e.target;
        const body = { name: f.name.value, email_domain: f.email_domain.value, notes: f.notes.value };
        if (f.is_active) body.is_active = f.is_active.checked;
        try {
          await api(c.id ? 'PATCH' : 'POST', c.id ? `/companies/${c.id}` : '/companies', body);
          m.close();
          await ensureCompanies(true);
          draw();
        } catch (ex) {
          $('#co-err', m.el).textContent = ex.message;
          $('#co-err', m.el).classList.remove('hidden');
        }
      });
    }

    return {
      actions: {
        'new-company': () => form(),
        'edit-company': (el) => form(S.companies.find((c) => c.id === Number(el.dataset.id))),
      },
    };
  }

  // ---------------------------------------------------------------- users

  async function viewUsers(q, token) {
    let users = [];
    let filter = { company_id: q.company_id || '', role: q.role || '' };
    await ensureCompanies();
    async function load() {
      users = (await api('GET', `/users${filter.company_id ? '?company_id=' + filter.company_id : ''}`)).users;
    }
    await load();
    if (stale(token)) return;

    const statusOf = (u) =>
      !u.is_active ? html`<span class="badge">Disabled</span>` : !u.has_password ? html`<span class="badge s-awaiting_client">Invited</span>` : html`<span class="badge s-resolved">Active</span>`;

    function draw() {
      const list = users.filter((u) => !filter.role || (filter.role === 'staff' ? u.role !== 'client' : u.role === filter.role));
      render(
        $view,
        html`
        <div class="page-head"><h1>Users</h1><span class="spacer"></span><button class="btn primary" data-action="new-user">Add user</button></div>
        <div class="toolbar">
          <select id="u-role"><option value="">All roles</option>${[['staff', 'Staff (admins & agents)'], ['client', 'Clients']].map(([v, l]) => opt(v, l, filter.role))}</select>
          <select id="u-company"><option value="">All companies</option>${S.companies.map((c) => opt(c.id, c.name, filter.company_id))}</select>
        </div>
        <div class="card"><div class="table-wrap"><table class="list">
          <thead><tr><th>Name</th><th>Role</th><th class="hide-sm">Company</th><th>Status</th><th class="hide-sm">Last seen</th><th></th></tr></thead>
          <tbody>${list.length
            ? list.map(
                (u) => html`<tr>
                  <td><b>${u.name}</b><div class="muted small">${u.email}</div></td>
                  <td>${cap(u.role)}</td>
                  <td class="hide-sm">${u.company_name || html`<span class="muted">-</span>`}</td>
                  <td>${statusOf(u)}</td>
                  <td class="hide-sm muted">${u.last_seen_at ? timeAgo(u.last_seen_at) : u.last_login_at ? timeAgo(u.last_login_at) : 'Never'}</td>
                  <td style="text-align:right;white-space:nowrap">
                    ${u.is_active ? html`<button class="btn sm" data-action="invite" data-id="${u.id}" title="Email a link to set a new password">${u.has_password ? 'Send reset' : 'Resend invite'}</button>` : ''}
                    <button class="btn sm" data-action="edit-user" data-id="${u.id}">Edit</button></td></tr>`
              )
            : html`<tr><td colspan="6" class="empty">No users match.</td></tr>`}</tbody>
        </table></div></div>`
      );
    }
    draw();

    function form(u = {}) {
      const isNew = !u.id;
      const m = modal(html`
        <h2 style="margin-bottom:14px">${isNew ? 'Add user' : 'Edit user'}</h2>
        <form id="u-form">
          <p class="error-text hidden" id="u-err"></p>
          <label class="field"><span>Full name</span><input name="name" required value="${u.name || ''}"></label>
          ${isNew ? html`<label class="field"><span>Email</span><input type="email" name="email" required></label>` : html`<p class="muted small">${u.email}</p>`}
          <div class="row">
            <label class="field"><span>Role</span><select name="role">${[['client', 'Client'], ['agent', 'Agent (staff)'], ['admin', 'Admin (staff)']].map(([v, l]) => opt(v, l, u.role || 'client'))}</select></label>
            <label class="field" id="u-company-field"><span>Company</span><select name="company_id"><option value="">Choose…</option>${S.companies.map((c) => opt(c.id, c.name, u.company_id || filter.company_id))}</select></label>
          </div>
          <label class="field"><span>Phone <span class="muted">(optional)</span></span><input name="phone" value="${u.phone || ''}"></label>
          ${isNew
            ? html`<label class="check field"><input type="checkbox" name="send_invite" checked> Email an invite link so they can set their own password</label>
                <label class="field hidden" id="u-pw"><span>Password</span><input type="password" name="password" minlength="8" autocomplete="new-password"></label>`
            : html`<label class="check field"><input type="checkbox" name="is_active" ${u.is_active ? 'checked' : ''}> Account active</label>
                <label class="check field"><input type="checkbox" name="notify_email" ${u.notify_email ? 'checked' : ''}> Receives email notifications</label>`}
          <div class="form-actions"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" type="submit">${isNew ? 'Create user' : 'Save'}</button></div>
        </form>`);
      const f = $('#u-form', m.el);
      const sync = () => {
        $('#u-company-field', m.el).classList.toggle('hidden', f.role.value !== 'client');
        if (f.send_invite) $('#u-pw', m.el).classList.toggle('hidden', f.send_invite.checked);
      };
      f.addEventListener('change', sync);
      sync();
      f.addEventListener('submit', async (e) => {
        e.preventDefault();
        const body = { name: f.name.value, role: f.role.value, company_id: f.company_id.value || null, phone: f.phone.value };
        if (isNew) {
          body.email = f.email.value;
          body.send_invite = f.send_invite.checked;
          if (!body.send_invite) body.password = f.password.value;
        } else {
          body.is_active = f.is_active.checked;
          body.notify_email = f.notify_email.checked;
        }
        try {
          await api(isNew ? 'POST' : 'PATCH', isNew ? '/users' : `/users/${u.id}`, body);
          m.close();
          toast(isNew ? 'User created' : 'User updated', isNew && body.send_invite ? html`Invite email sent to ${body.email}.` : '');
          await load();
          draw();
        } catch (ex) {
          $('#u-err', m.el).textContent = ex.message;
          $('#u-err', m.el).classList.remove('hidden');
        }
      });
    }

    return {
      actions: {
        'new-user': () => form(),
        'edit-user': (el) => form(users.find((u) => u.id === Number(el.dataset.id))),
        async invite(el) {
          busy(el, true, 'Sending…');
          try {
            await api('POST', `/users/${el.dataset.id}/invite`);
            toast('Email sent', html`A link to set their password is on its way.`);
          } catch (ex) {
            toast('Could not send', html`${ex.message}`, { type: 'error' });
          }
          busy(el, false);
        },
      },
      async onChange(e) {
        if (e.target.id === 'u-role') filter.role = e.target.value;
        else if (e.target.id === 'u-company') {
          filter.company_id = e.target.value;
          await load();
        } else return;
        draw();
      },
    };
  }

  // ---------------------------------------------------------------- profile

  async function viewProfile() {
    const u = S.user;
    const notifState = () =>
      !('Notification' in window) ? 'unsupported' : Notification.permission;
    render(
      $view,
      html`
      <div class="page-head"><h1>Profile</h1></div>
      <div class="grid-2" style="grid-template-columns:1fr 1fr;align-items:start">
        <form class="card card-pad" id="p-form">
          <h2 style="margin-bottom:14px">Your details</h2>
          <label class="field"><span>Name</span><input name="name" required value="${u.name}"></label>
          <label class="field"><span>Email</span><input value="${u.email}" disabled></label>
          <label class="field"><span>Phone</span><input name="phone" value="${u.phone || ''}"></label>
          <label class="check field"><input type="checkbox" name="notify_email" ${u.notify_email ? 'checked' : ''}> Email me about ${S.staff ? 'new tickets and client replies' : 'replies and status changes on my tickets'}</label>
          <div class="form-actions"><button class="btn primary" type="submit">Save</button></div>
        </form>
        <div>
          <form class="card card-pad" id="pw-form" style="margin-bottom:12px">
            <h2 style="margin-bottom:14px">Change password</h2>
            <label class="field"><span>Current password</span><input type="password" name="current" required autocomplete="current-password"></label>
            <label class="field"><span>New password</span><input type="password" name="password" minlength="8" required autocomplete="new-password"></label>
            <div class="form-actions"><button class="btn primary" type="submit">Update password</button></div>
          </form>
          <div class="card card-pad">
            <h2 style="margin-bottom:6px">Desktop notifications</h2>
            <p class="muted" style="margin-top:0">Get a pop-up on this computer when there's activity and this tab is in the background.</p>
            <div id="notif-state"></div>
          </div>
        </div>
      </div>`
    );
    const drawNotif = () => {
      const st = notifState();
      render(
        $('#notif-state'),
        st === 'granted'
          ? html`<span class="badge s-resolved">Enabled on this browser</span>`
          : st === 'denied'
            ? html`<span class="muted small">Blocked - allow notifications for this site in your browser settings.</span>`
            : st === 'unsupported'
              ? html`<span class="muted small">Not supported by this browser.</span>`
              : html`<button class="btn" data-action="enable-notif">Enable notifications</button>`
      );
    };
    drawNotif();

    $('#p-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target;
      try {
        S.user = (await api('PATCH', '/auth/me', { name: f.name.value, phone: f.phone.value, notify_email: f.notify_email.checked })).user;
        $('#who').textContent = S.user.name;
        toast('Saved', '');
      } catch (ex) {
        toast('Could not save', html`${ex.message}`, { type: 'error' });
      }
    });
    $('#pw-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target;
      try {
        await api('POST', '/auth/password', { current: f.current.value, password: f.password.value });
        f.reset();
        toast('Password updated', '');
      } catch (ex) {
        toast('Could not update password', html`${ex.message}`, { type: 'error' });
      }
    });
    return {
      actions: {
        'enable-notif': async () => {
          await Notification.requestPermission();
          drawNotif();
        },
      },
    };
  }

  boot().catch((err) => {
    if (err.message !== 'Signed out') render($view, html`<div class="card empty">Could not load the portal: ${err.message}</div>`);
  });
})();
